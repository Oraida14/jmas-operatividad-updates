﻿// ======================= IMPORTS =======================
const express = require('express');
const http = require('http');
const path = require('path');
const socketIo = require('socket.io');
const cors = require('cors');
const mqtt = require('mqtt');
const fs = require('fs');
const os = require('os');
const csv = require('csv-parser');
const { execSync } = require('child_process');
const { HttpsProxyAgent } = require('https-proxy-agent');
let mysqlPromise = null;
try {
  mysqlPromise = require('mysql2/promise');
} catch (_) {
  mysqlPromise = null;
}

const fetch = (...args) =>
  import('node-fetch').then(({ default: fetch }) => fetch(...args));
const XLSX = require('xlsx');
const createCsvWriter = require('csv-writer').createObjectCsvWriter;




const GEO_FILE = path.join(__dirname, "geocodeCache.json");
const V2_INGEST_FILE = path.join(__dirname, "locations_v2.ndjson");
const ALERTS_FILE = path.join(__dirname, "emergency_alerts.ndjson");
const ACTIVE_ALERTS_FILE = path.join(__dirname, "active_alerts.json");
const MESSAGES_FILE = path.join(__dirname, "operational_messages.ndjson");
const MESSAGE_REPLIES_FILE = path.join(__dirname, "operational_message_replies.ndjson");
const DESTINATIONS_FILE = path.join(__dirname, "operational_destinations.ndjson");
const EVIDENCE_DIR = path.join(__dirname, "evidences");
const ORDER_REPORTS_DIR = path.join(__dirname, "order_reports");
const ORDER_CLOSE_REPORTS_FILE = path.join(ORDER_REPORTS_DIR, "order_close_reports.ndjson");
const MESSAGE_DELETIONS_FILE = path.join(__dirname, "operational_message_deletions.json");
const DESTINATION_TASKS_FILE = path.join(__dirname, "operational_destination_tasks.json");
const DEVICE_REGISTRY_FILE = path.join(__dirname, "deviceRegistry.json");
const DEVICE_TOKENS_FILE = path.join(__dirname, "deviceTokens.json");
const CURRENT_UNITS_FILE = path.join(__dirname, "current_units.json");
const DEVICE_DEPARTMENTS_FILE = path.join(__dirname, "device_departments.json");
const APP_UPDATE_MANIFEST_FILE = path.join(__dirname, "app_update_manifest.json");
const SITE_LIVE_DATA_FILE = process.env.SITE_LIVE_DATA_FILE || path.join(__dirname, "site_live_data.json");
const TRACKING_MODE = (process.env.TRACKING_MODE || "hybrid").toLowerCase();
const MQTT_BROKER_URL = process.env.MQTT_BROKER_URL || "wss://demo.tbmq.io/mqtt";
const MQTT_USERNAME = process.env.MQTT_USERNAME || "demo";
const MQTT_PASSWORD = process.env.MQTT_PASSWORD || "";
const EVIDENCE_UPLOAD_TOKEN = process.env.EVIDENCE_UPLOAD_TOKEN || "5kvJbi8NKPtkYxFYsyACfeOquGBleQkY";
const MAX_BATCH_POINTS = Number(process.env.MAX_BATCH_POINTS || 500);
const CURRENT_TRACKER_APP_ID = "jmas-operativa-v2";
const CURRENT_APP_ONLY = process.env.CURRENT_APP_ONLY === "true";
const UNIT_RETENTION_MS = Number(process.env.UNIT_RETENTION_MS || 0);
const cacheGeo = {};
let warnedMissingTokens = false;

const SITE_CATALOG = {
  p11: {
    id: "p11",
    table: "p11",
    type: "pozo",
    name: "Pozo 11",
    sample: {
      p11_ndx: 23009,
      Gasto_Instantaneo: 29.8238,
      Presion_Instantanea: 22.7398,
      Bomba_Pozo: 1,
      t_stamp: "2026-06-03 12:44:11"
    }
  },
  p25: {
    id: "p25",
    table: "p25",
    type: "pozo",
    name: "Pozo 25",
    sample: {
      Color: null,
      Gasto_Instantaneo: null,
      Gasto_Instantaneo_2: null,
      Gasto_Instantaneo_3: null,
      Nivel_1: null,
      Presion_Instantanea: null,
      Presion_Instantanea_2: null,
      Presion_Instantanea_3: null,
      Hrs_op: null,
      frecuencia: null,
      t_stamp: null
    }
  },
  p247: {
    id: "p247",
    table: "p247",
    type: "pozo",
    name: "Pozo 247",
    sample: {
      Color: 4,
      Gasto_Instantaneo: 48,
      Presion_Instantanea: 20,
      Hrs_op: 0,
      t_stamp: "2026-06-03 12:53:13"
    }
  },
  p251: {
    id: "p251",
    table: "p251",
    type: "pozo",
    name: "Pozo 251",
    sample: {
      Color: null,
      Gasto_Instantaneo: null,
      Presion_Instantanea: null,
      Hrs_op: null,
      t_stamp: null
    }
  },
  reb_7: {
    id: "reb_7",
    table: "reb_7",
    type: "rebombeo",
    name: "Rebombeo 7",
    sample: {
      "1_2_Frec_Max_3030": 50500,
      t_stamp: "2026-06-03 12:51:01"
    }
  },
  tanque_plutarco: {
    id: "tanque_plutarco",
    table: "tanque_plutarco",
    type: "tanque",
    name: "Tanque Plutarco",
    sample: {
      nivel: null,
      nivel_porcentaje: null,
      presion_antes: null,
      presion_despues: null,
      caudal: null,
      voltaje: null,
      actuador: null,
      acumulado: null,
      Nivel_1: null,
      t_stamp: null
    }
  },
  tanque_lajas_nivel: {
    id: "tanque_lajas_nivel",
    table: "tanque_lajas_nivel",
    type: "tanque",
    name: "Tanque Lajas",
    sample: {
      Nivel_1: 2.54867,
      t_stamp: "2025-09-02 11:23:45"
    }
  }
};

function loadDeviceTokens() {
  let tokens = {};

  if (fs.existsSync(DEVICE_REGISTRY_FILE)) {
    try {
      const registry = JSON.parse(fs.readFileSync(DEVICE_REGISTRY_FILE, "utf8"));
      Object.entries(registry).forEach(([tabletId, info]) => {
        if (typeof info === "string") {
          tokens[tabletId] = info;
        } else if (info && info.token) {
          tokens[tabletId] = info.token;
        }
      });
    } catch (err) {
      console.log("Error leyendo deviceRegistry.json:", err.message);
    }
  }

  if (fs.existsSync(DEVICE_TOKENS_FILE)) {
    try {
      tokens = {
        ...tokens,
        ...JSON.parse(fs.readFileSync(DEVICE_TOKENS_FILE, "utf8"))
      };
    } catch (err) {
      console.log("Error leyendo deviceTokens.json:", err.message);
    }
  }

  if (process.env.DEVICE_TOKENS_JSON) {
    try {
      tokens = {
        ...tokens,
        ...JSON.parse(process.env.DEVICE_TOKENS_JSON)
      };
    } catch (err) {
      console.log("Error leyendo DEVICE_TOKENS_JSON:", err.message);
    }
  }

  return tokens;
}

let deviceTokens = loadDeviceTokens();
let mqttClient = null;
let mqttStatus = {
  connected: false,
  lastConnectAt: null,
  lastMessageAt: null,
  lastTopic: "",
  lastError: ""
};

function readWindowsProxy() {
  try {
    const output = execSync(
      'reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyEnable & reg query "HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings" /v ProxyServer',
      { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] }
    );
    const enabled = /ProxyEnable\s+REG_DWORD\s+0x1/i.test(output);
    const serverMatch = output.match(/ProxyServer\s+REG_SZ\s+([^\r\n]+)/i);
    const proxyServer = serverMatch ? serverMatch[1].trim() : "";
    if (!enabled || !proxyServer) return "";
    return proxyServer.startsWith("http") ? proxyServer : `http://${proxyServer}`;
  } catch (_) {
    return "";
  }
}

function mqttConnectOptions() {
  const options = {
    clean: true,
    connectTimeout: 15000,
    reconnectPeriod: 5000,
    keepalive: 30,
    clientId: `jmas-central-${Date.now()}-${Math.random().toString(16).slice(2)}`
  };

  if (MQTT_USERNAME) options.username = MQTT_USERNAME;
  if (MQTT_PASSWORD) options.password = MQTT_PASSWORD;

  const configuredLocalAddress = String(process.env.MQTT_LOCAL_ADDRESS || "").trim();
  const networkInterfaces = os.networkInterfaces();
  const wifiLocalAddress = Object.entries(networkInterfaces)
    .flatMap(([name, addresses]) =>
      (addresses || []).map((address) => ({ name, ...address }))
    )
    .find(
      (address) =>
        address.family === "IPv4" &&
        !address.internal &&
        (
          /wi-?fi|wlan|wireless/i.test(address.name) ||
          address.address.startsWith("192.168.1.")
        )
    )?.address;
  const localAddress = configuredLocalAddress || wifiLocalAddress || "";
  const windowsProxy = readWindowsProxy();
  const tlm02Proxy =
    process.env.COMPUTERNAME?.toUpperCase() === "TLM02"
      ? "http://172.16.11.15:3128"
      : "";
  const configuredProxy =
    process.env.MQTT_PROXY ||
    process.env.HTTPS_PROXY ||
    process.env.HTTP_PROXY ||
    windowsProxy ||
    tlm02Proxy;
  const proxyEnabled =
    process.env.MQTT_USE_PROXY !== "false" &&
    Boolean(configuredProxy);
  const proxyUrl = proxyEnabled ? configuredProxy : "";
  if (localAddress && MQTT_BROKER_URL.startsWith("wss://")) {
    options.wsOptions = {
      localAddress
    };
    console.log(`MQTT usando interfaz Wi-Fi: ${localAddress}`);
  } else if (proxyUrl && MQTT_BROKER_URL.startsWith("wss://")) {
    options.wsOptions = {
      agent: new HttpsProxyAgent(proxyUrl)
    };
    console.log(`MQTT usando proxy: ${proxyUrl}`);
  } else if (!proxyEnabled) {
    console.log("MQTT directo sin proxy");
  }

  return options;
}

function dbTelemetryEnabled() {
  return Boolean(
    mysqlPromise &&
    process.env.JMAS_DB_HOST &&
    process.env.JMAS_DB_USER &&
    process.env.JMAS_DB_PASSWORD
  );
}

async function readLatestSiteRow(site) {
  if (!dbTelemetryEnabled()) return null;

  const table = String(site.table || "");
  if (!/^[a-zA-Z0-9_]+$/.test(table)) {
    throw new Error("Tabla no permitida");
  }

  const connection = await mysqlPromise.createConnection({
    host: process.env.JMAS_DB_HOST,
    port: Number(process.env.JMAS_DB_PORT || 3306),
    user: process.env.JMAS_DB_USER,
    password: process.env.JMAS_DB_PASSWORD,
    database: process.env.JMAS_DB_NAME || "datos",
    connectTimeout: 5000,
    timezone: "local"
  });

  try {
    const [rows] = await connection.query(
      `SELECT * FROM \`${table}\` ORDER BY \`t_stamp\` DESC LIMIT 1`
    );
    return rows[0] || null;
  } finally {
    await connection.end();
  }
}

function minutesSince(value) {
  if (!value) return null;
  const time = new Date(value).getTime();
  if (Number.isNaN(time)) return null;
  return Math.max(0, Math.round((Date.now() - time) / 60000));
}

function firstValue(row, names) {
  for (const name of names) {
    if (row && row[name] !== undefined && row[name] !== null && row[name] !== "") {
      return row[name];
    }
  }
  return null;
}

function normalizeTelemetryRow(row) {
  if (!row || typeof row !== "object") return null;

  return {
    ...row,
    Gasto_Instantaneo: firstValue(row, ["Gasto_Instantaneo", "gasto_lps", "gasto", "flow", "flow_lps"]),
    Presion_Instantanea: firstValue(row, ["Presion_Instantanea", "presion_psi", "presion", "pressure", "pressure_psi"]),
    nivel_porcentaje: firstValue(row, ["nivel_porcentaje", "nivel_pct", "level_percent"]),
    nivel: firstValue(row, ["nivel", "Nivel_1", "level"]),
    Bomba_Pozo: firstValue(row, ["Bomba_Pozo", "bomba", "pump"]),
    frecuencia: firstValue(row, ["frecuencia", "frequency", "frecuencia_hz"]),
    voltaje: firstValue(row, ["voltaje", "voltage", "voltaje_v"]),
    t_stamp: firstValue(row, ["t_stamp", "ultima_comunicacion", "lastSeen", "last_seen", "timestamp"])
  };
}

function readSiteTelemetryFile(site) {
  if (!fs.existsSync(SITE_LIVE_DATA_FILE)) return null;

  try {
    const data = JSON.parse(fs.readFileSync(SITE_LIVE_DATA_FILE, "utf8"));
    const candidates = [
      site.id,
      site.table,
      site.name,
      String(site.id || "").toLowerCase(),
      String(site.name || "").toLowerCase()
    ];

    for (const key of candidates) {
      if (data[key]) return normalizeTelemetryRow(data[key]);
    }

    if (Array.isArray(data.sites)) {
      const row = data.sites.find(item => {
        const id = String(item.id || item.siteId || item.table || item.nombre || item.name || "").toLowerCase();
        return id === site.id || id === site.table || id === String(site.name || "").toLowerCase();
      });
      return normalizeTelemetryRow(row);
    }
  } catch (err) {
    console.log("Error leyendo site_live_data.json:", err.message);
  }

  return null;
}

function allMatchingValues(row, pattern) {
  return Object.entries(row || {})
    .filter(([key, value]) => pattern.test(key) && value !== null && value !== undefined && value !== "")
    .map(([key, value]) => ({ key, value }));
}

function normalizedSiteTelemetry(site, row, source) {
  row = normalizeTelemetryRow(row) || {};
  const lastSeen = row?.t_stamp || null;
  const ageMinutes = minutesSince(lastSeen);
  const offline = ageMinutes === null || ageMinutes > 30;
  const status = offline ? "sin_comunicacion" : "operativo";

  const flowValues = allMatchingValues(row, /^Gasto_Instantaneo/i);
  const pressureValues = allMatchingValues(row, /^Presion_Instantanea/i);
  const levelValues = allMatchingValues(row, /^(nivel|Nivel_1|nivel_porcentaje)$/i);
  const pumpRaw = firstValue(row, ["Bomba_Pozo", "Bomba", "Color", "actuador"]);
  const pumpText = typeof pumpRaw === "string" ? pumpRaw.toLowerCase() : "";
  const pump = pumpRaw === null
    ? null
    : (pumpText.includes("encendida") || pumpText.includes("on") || Number(pumpRaw) > 0 ? "encendida" : "apagada");

  return {
    id: site.id,
    table: site.table,
    type: site.type,
    name: site.name,
    status,
    source,
    lastSeen,
    ageMinutes,
    metrics: {
      flow: firstValue(row, ["Gasto_Instantaneo", "caudal"]),
      pressure: firstValue(row, ["Presion_Instantanea", "presion_antes", "presion_despues"]),
      level: firstValue(row, ["nivel_porcentaje", "nivel", "Nivel_1"]),
      pump,
      frequency: firstValue(row, ["frecuencia", "1_2_Frec_Max_3030"]),
      voltage: firstValue(row, ["voltaje"]),
      hours: firstValue(row, ["Hrs_op", "Horas_Operacion_Rebombe"])
    },
    series: {
      flows: flowValues,
      pressures: pressureValues,
      levels: levelValues
    },
    raw: row || {}
  };
}

async function buildSiteTelemetrySnapshot(siteId) {
  const key = String(siteId || "").trim().toLowerCase();
  const site = SITE_CATALOG[key];
  if (!site) return null;

  const fileRow = readSiteTelemetryFile(site);
  if (fileRow) {
    return normalizedSiteTelemetry(site, fileRow, "json");
  }

  try {
    const row = await readLatestSiteRow(site);
    return normalizedSiteTelemetry(site, row || site.sample, row ? "mysql" : "piloto");
  } catch (_) {
    return normalizedSiteTelemetry(site, site.sample, "piloto");
  }
}

function loadActiveAlerts() {
  if (!fs.existsSync(ACTIVE_ALERTS_FILE)) return {};

  try {
    return JSON.parse(fs.readFileSync(ACTIVE_ALERTS_FILE, "utf8"));
  } catch (err) {
    console.log("Error leyendo active_alerts.json:", err.message);
    return {};
  }
}

let activeAlerts = loadActiveAlerts();

function saveActiveAlerts() {
  fs.writeFileSync(ACTIVE_ALERTS_FILE, JSON.stringify(activeAlerts, null, 2));
}

function alertStorageId(tabletId, type) {
  return `${String(tabletId || "unidad").replace(/[^a-zA-Z0-9_-]/g, "-")}:${String(type || "emergency").replace(/[^a-zA-Z0-9_-]/g, "-")}`;
}

function appendAlertEvent(event) {
  fs.appendFileSync(ALERTS_FILE, JSON.stringify({
    receivedAt: Date.now(),
    ...event
  }) + "\n");
}

function appendOperationalMessage(message) {
  fs.appendFileSync(MESSAGES_FILE, JSON.stringify({
    receivedAt: Date.now(),
    ...message
  }) + "\n");
}

function appendOperationalReply(reply) {
  fs.appendFileSync(MESSAGE_REPLIES_FILE, JSON.stringify({
    receivedAt: Date.now(),
    ...reply
  }) + "\n");
}

function markOperationalMessageRead(receipt) {
  if (!receipt?.messageId || !fs.existsSync(MESSAGES_FILE)) return false;

  const lines = fs.readFileSync(MESSAGES_FILE, "utf8").split(/\r?\n/);
  let changed = false;

  const updatedLines = lines.map(line => {
    if (!line.trim()) return line;
    try {
      const message = JSON.parse(line);
      if (message.messageId !== receipt.messageId) return line;

      const nextReadAt = Number(receipt.readAt || receipt.timestamp || Date.now());
      const currentReadAt = Number(message.readAt || 0);
      if (currentReadAt && currentReadAt <= nextReadAt && message.readBy === receipt.tabletId) {
        return line;
      }

      changed = true;
      return JSON.stringify({
        ...message,
        readBy: receipt.tabletId,
        readAt: nextReadAt
      });
    } catch {
      return line;
    }
  });

  if (changed) {
    fs.writeFileSync(MESSAGES_FILE, updatedLines.join("\n"));
  }

  return changed;
}

function applyReadReceiptsToMessages(messages, replies) {
  const receipts = new Map();

  (Array.isArray(replies) ? replies : []).forEach(reply => {
    if (reply?.type !== "read_receipt" || !reply.messageId) return;
    const readAt = Number(reply.readAt || reply.timestamp || reply.receivedAt || 0);
    const current = receipts.get(reply.messageId);
    if (!current || readAt >= Number(current.readAt || 0)) {
      receipts.set(reply.messageId, {
        readBy: reply.tabletId,
        readAt
      });
    }
  });

  return (Array.isArray(messages) ? messages : []).map(message => {
    if (message.readAt || !message.messageId) return message;
    const receipt = receipts.get(message.messageId);
    return receipt ? { ...message, ...receipt } : message;
  });
}

function saveEvidenceRecord(data, imageBuffer) {
  const tabletId = String(data.tabletId || "").trim();
  const destinationId = String(data.destinationId || "").trim();
  const stage = String(data.stage || "").trim();
  const timestamp = normalizeTimestamp(data.timestamp);

  if (!tabletId || !destinationId || !stage || !imageBuffer?.length) {
    throw new Error("Evidencia incompleta");
  }

  fs.mkdirSync(EVIDENCE_DIR, { recursive: true });
  const safeDestination = destinationId.replace(/[^a-zA-Z0-9_-]/g, "-").slice(0, 80);
  const safeStage = stage.replace(/[^a-zA-Z0-9_-]/g, "-").slice(0, 30);
  const fileName = `${safeDestination}-${safeStage}-${timestamp}.jpg`;
  const filePath = path.join(EVIDENCE_DIR, fileName);
  fs.writeFileSync(filePath, imageBuffer);

  const evidence = {
    type: "evidence",
    tabletId,
    destinationId,
    folio: data.folio || "",
    platform: data.platform || "Tracking",
    stage,
    mimeType: data.mimeType || "image/jpeg",
    fileName,
    fileUrl: `/api/evidences/${encodeURIComponent(fileName)}`,
    timestamp
  };

  appendOperationalReply(evidence);
  io.emit("operationalReply", evidence);
  io.emit("orderEvidence", evidence);
  return evidence;
}

function saveOrderCloseReport(data) {
  const destinationId = String(data.destinationId || "").trim();
  const tabletId = String(data.tabletId || "").trim();
  const timestamp = normalizeTimestamp(data.timestamp);

  if (!destinationId || !tabletId) {
    throw new Error("Reporte de cierre incompleto");
  }

  fs.mkdirSync(ORDER_REPORTS_DIR, { recursive: true });
  const report = {
    type: "order_close_report",
    tabletId,
    destinationId,
    folio: data.folio || "",
    platform: data.platform || "Tracking",
    name: data.name || "",
    note: data.note || "",
    address: data.address || "",
    priority: data.priority || "",
    orderType: data.orderType || "",
    status: data.status || "Finalizado",
    timeline: data.timeline || {},
    evidence: data.evidence || {},
    appVersion: data.appVersion || "",
    appVersionCode: data.appVersionCode || "",
    timestamp
  };

  fs.appendFileSync(ORDER_CLOSE_REPORTS_FILE, JSON.stringify({
    receivedAt: Date.now(),
    ...report
  }) + "\n");

  appendOperationalReply(report);
  io.emit("operationalReply", report);
  io.emit("orderCloseReport", report);
  return report;
}

function readRecentNdjson(filePath, limit = 100) {
  if (!fs.existsSync(filePath)) return [];

  const lines = fs.readFileSync(filePath, "utf8")
    .split(/\r?\n/)
    .filter(Boolean)
    .slice(-Math.max(1, Math.min(Number(limit) || 100, 500)));

  const records = [];
  let skipped = 0;
  for (const line of lines) {
    try {
      records.push(JSON.parse(line));
    } catch {
      skipped += 1;
    }
  }

  if (skipped) {
    console.log(`Aviso: ${path.basename(filePath)} contiene ${skipped} linea(s) incompleta(s).`);
  }

  return records.reverse();
}

function appendOperationalDestination(destination) {
  fs.appendFileSync(DESTINATIONS_FILE, JSON.stringify({
    receivedAt: Date.now(),
    ...destination
  }) + "\n");
}

function messageRecordId(item) {
  if (!item) return "";
  if (item.destinationId) return `destination:${item.destinationId}`;
  if (item.type === "read_receipt") {
    return `receipt:${item.tabletId || ""}:${item.messageId || ""}:${item.readAt || item.timestamp || item.receivedAt || ""}`;
  }
  if (item.type === "reply") {
    return `reply:${item.tabletId || ""}:${item.messageId || ""}:${item.timestamp || item.receivedAt || ""}`;
  }
  if (item.messageId) return `message:${item.messageId}`;
  return `${item.type || "item"}:${item.tabletId || item.target || ""}:${item.timestamp || item.receivedAt || ""}`;
}

function loadMessageDeletions() {
  if (!fs.existsSync(MESSAGE_DELETIONS_FILE)) {
    return { messages: [], replies: [], destinations: [] };
  }

  try {
    return {
      messages: [],
      replies: [],
      destinations: [],
      ...JSON.parse(fs.readFileSync(MESSAGE_DELETIONS_FILE, "utf8"))
    };
  } catch (err) {
    console.log("Error leyendo operational_message_deletions.json:", err.message);
    return { messages: [], replies: [], destinations: [] };
  }
}

let messageDeletions = loadMessageDeletions();

function saveMessageDeletions() {
  fs.writeFileSync(MESSAGE_DELETIONS_FILE, JSON.stringify(messageDeletions, null, 2));
}

function filterDeletedMessageRecords(type, records) {
  const deleted = new Set(messageDeletions[type] || []);
  return records.filter(item => !deleted.has(messageRecordId(item)));
}

function loadDestinationTasks() {
  if (!fs.existsSync(DESTINATION_TASKS_FILE)) return {};

  try {
    return JSON.parse(fs.readFileSync(DESTINATION_TASKS_FILE, "utf8"));
  } catch (err) {
    console.log("Error leyendo operational_destination_tasks.json:", err.message);
    return {};
  }
}

let destinationTasks = loadDestinationTasks();

function saveDestinationTasks() {
  fs.writeFileSync(DESTINATION_TASKS_FILE, JSON.stringify(destinationTasks, null, 2));
}

function activeDestinationTasks() {
  return Object.values(destinationTasks)
    .filter(task => task.status !== "completed")
    .sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
}

function loadDeviceNames() {
  const names = {};

  if (!fs.existsSync(DEVICE_REGISTRY_FILE)) return names;

  try {
    const registry = JSON.parse(fs.readFileSync(DEVICE_REGISTRY_FILE, "utf8"));
    Object.entries(registry).forEach(([tabletId, info]) => {
      if (info && typeof info === "object" && info.name) {
        names[tabletId] = info.name;
      }
    });
  } catch (err) {
    console.log("Error leyendo nombres de deviceRegistry.json:", err.message);
  }

  return names;
}

const registeredDeviceNames = loadDeviceNames();

function isValidDeviceToken(tabletId, token) {
  const configuredIds = Object.keys(deviceTokens);

  if (configuredIds.length === 0) {
    if (!warnedMissingTokens) {
      console.log("Aviso: /api/v2/locations/batch no tiene tokens configurados.");
      warnedMissingTokens = true;
    }
    return true;
  }

  return Boolean(tabletId && token && deviceTokens[tabletId] === token);
}



// ðŸ”¥ cargar cache al iniciar
if (fs.existsSync(GEO_FILE)) {
  try {
    const data = fs.readFileSync(GEO_FILE, "utf8");
    Object.assign(cacheGeo, data ? JSON.parse(data) : {});
    console.log("ðŸ“‚ Cache geocode cargado");
  } catch (err) {
    console.log("âš ï¸ Error cargando cache");
  }
}

// ======================= INIT =======================
console.log("ðŸŸ¢ Iniciando servidor...");

const app = express();
app.get("/supervisores", (req, res) => {
  res.sendFile(path.join(__dirname, "../public/supervisores.html"));
});

app.use(express.static(path.join(__dirname, '../public')));
const server = http.createServer(app);

// ======================= CONFIG =======================
app.use(cors());
app.use(express.json({ limit: "2mb" }));

const io = socketIo(server, {
  cors: { origin: "*", methods: ["GET", "POST"] }
});

/// ======================= MEMORIA =======================
function loadCurrentUnits() {
  if (!fs.existsSync(CURRENT_UNITS_FILE)) return {};
  try {
    return JSON.parse(fs.readFileSync(CURRENT_UNITS_FILE, "utf8"));
  } catch (_) {
    return {};
  }
}

let unidades = loadCurrentUnits();
let currentUnitsSaveTimer = null;

function scheduleCurrentUnitsSave() {
  if (currentUnitsSaveTimer) return;
  currentUnitsSaveTimer = setTimeout(() => {
    currentUnitsSaveTimer = null;
    fs.writeFileSync(CURRENT_UNITS_FILE, JSON.stringify(unidades, null, 2));
  }, 1000);
}

const nombresUnidades = {
  "ID_TABLET": "VictorV",
  "EduardoC": "Eduardo Corral",
  ...registeredDeviceNames
};

function loadDeviceDepartments() {
  if (!fs.existsSync(DEVICE_DEPARTMENTS_FILE)) {
    return {
      departments: [
        "Guardia Ricardo Cardoza",
        "Guardia Ing. Eliseo Reyes",
        "Telemetria",
        "Soldadores",
        "Electricos",
        "Cloro",
        "Lic Heriberto Rocha",
        "Perdidas",
        "ACM",
        "Sin asignar"
      ],
      devices: {}
    };
  }

  try {
    const data = JSON.parse(fs.readFileSync(DEVICE_DEPARTMENTS_FILE, "utf8"));
    return {
      departments: Array.isArray(data.departments) ? data.departments : [],
      devices: data.devices && typeof data.devices === "object" ? data.devices : {}
    };
  } catch (err) {
    console.log("Error leyendo device_departments.json:", err.message);
    return { departments: [], devices: {} };
  }
}

let deviceDepartments = loadDeviceDepartments();

function saveDeviceDepartments() {
  const departments = [
    ...new Set([
      ...deviceDepartments.departments,
      ...Object.values(deviceDepartments.devices),
      "Sin asignar"
    ].filter(Boolean))
  ];
  deviceDepartments = { departments, devices: deviceDepartments.devices };
  fs.writeFileSync(DEVICE_DEPARTMENTS_FILE, JSON.stringify(deviceDepartments, null, 2));
}

function unitDepartment(tabletId, displayName) {
  return deviceDepartments.devices[tabletId]
    || deviceDepartments.devices[displayName]
    || "Sin asignar";
}

function enrichUnit(unit, key = "") {
  const tabletId = unit.tabletId || unit.sourceTabletId || key || unit.id;
  const id = unit.id || nombresUnidades[tabletId] || tabletId;
  return {
    ...unit,
    id,
    tabletId,
    department: deviceDepartments.devices[tabletId]
      || deviceDepartments.devices[id]
      || unit.department
      || "Sin asignar"
  };
}

function shouldShowUnitId(id) {
  const value = String(id || "").trim();
  return /\s/.test(value);
}

function visibleUnits() {
  return Object.entries(unidades)
    .map(([key, unit]) => enrichUnit(unit, key))
    .filter(unit => shouldShowUnitId(unit.id));
}

function normalizeName(value) {
  return String(value || "")
    .trim()
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .toLowerCase();
}

function resolveTargetAliases(target) {
  const value = String(target || "all").trim() || "all";
  if (normalizeName(value) === "all") {
    return { target: "all", targetTabletId: "all", targetName: "Todas" };
  }

  const byTabletId = nombresUnidades[value];
  if (byTabletId) {
    return { target: value, targetTabletId: value, targetName: byTabletId };
  }

  const entry = Object.entries(nombresUnidades).find(([, name]) =>
    normalizeName(name) === normalizeName(value)
  );

  if (entry) {
    return { target: value, targetTabletId: entry[0], targetName: entry[1] };
  }

  return { target: value, targetTabletId: value, targetName: value };
}

function compactSiteKey(value) {
  return normalizeName(value).replace(/[^a-z0-9]/g, "");
}

function siteCoordinateKeys(site) {
  const keys = new Set([
    site.id,
    site.name,
    site.table,
    site.id.replace(/^p(\d+)$/i, "$1"),
    site.name.replace(/^pozo\s+/i, ""),
    site.id.replace(/^reb_(\d+)$/i, "REB $1"),
    site.id.replace(/^reb_(\d+)$/i, "REB$1"),
    site.id.replace(/^tanque_(.+)$/i, "tanque $1")
  ]);

  return [...keys]
    .map(value => String(value || "").trim())
    .filter(Boolean)
    .flatMap(value => [normalizeName(value), compactSiteKey(value)]);
}

function findSiteCoordinates(site, pozos) {
  const wanted = new Set(siteCoordinateKeys(site));
  const exact = pozos.find(item => {
    const name = String(item.nombre || "");
    return wanted.has(normalizeName(name)) || wanted.has(compactSiteKey(name));
  });
  if (exact) return exact;

  const wellNumber = String(site.id || "").match(/^p(\d+)$/i)?.[1];
  if (wellNumber) {
    return pozos.find(item => {
      const name = normalizeName(item.nombre || "");
      return new RegExp(`^${wellNumber}\\s*(r|rr)?$`, "i").test(name);
    }) || null;
  }

  return null;
}


let sesiones = {};
let recorridosDia = {}; // ðŸ”¥ NUEVO
const lastGoodLocations = {};



function guardarCacheGeo() {
  try {
    fs.writeFileSync(GEO_FILE, JSON.stringify(cacheGeo, null, 2));
  } catch (err) {
    console.log("âŒ Error guardando cache");
  }
}



function guardarRecorridos() {
  const fecha = new Date().toISOString().split("T")[0];
  const filePath = path.join(__dirname, `recorridos_${fecha}.json`);

  fs.writeFileSync(filePath, JSON.stringify(recorridosDia, null, 2));
}

setInterval(() => {
  guardarRecorridos();
  console.log("ðŸ’¾ Recorridos guardados");
}, 10000); // cada 10 segundos

function cargarRecorridos() {
  const fecha = new Date().toISOString().split("T")[0];
const filePath = path.join(__dirname, `recorridos_${fecha}.json`);

  if (fs.existsSync(filePath)) {
    const data = fs.readFileSync(filePath, "utf8");

    if (data.trim() !== "") {
      recorridosDia = JSON.parse(data);
      console.log("ðŸ“‚ Recorridos cargados");
    }
  }
}

cargarRecorridos();
// ======================= FORMATO SEGURO PARA MAPA =======================
function formatearParaMapa(unidades) {
  const now = Date.now();

  return Object.values(unidades)
    .filter(u => u && shouldShowUnitId(enrichUnit(u).id) && !isNaN(u.lat) && !isNaN(u.lng))
    .map(u => {
      const diff = now - (u.timestamp || 0);
      const estado = diff > 180000 ? "offline" : "online";

      return {
        name: u.id || "sin_nombre",
        position: {
          lat: Number(u.lat),
          lng: Number(u.lng)
        },
        tooltip: {
          content: "Estado: " + estado,
          enabled: true
        }
      };
    })
    .filter(u => u.position.lat !== 0 && u.position.lng !== 0);
}

// ======================= API =======================
app.get('/api/unidades', (req, res) => {

  const resultado = Object.values(unidades)
    .filter(u => u && shouldShowUnitId(enrichUnit(u).id) && !isNaN(u.lat) && !isNaN(u.lng))
    .map(u => ({
      lat: Number(u.lat),
      lng: Number(u.lng),
      tooltip: {
        content: {
          text: "Unidad: " + (u.id || "Sin nombre")
        },
        enabled: true
      }
    }));

  res.json({ data: resultado });
});

app.get("/api/devices/status", (req, res) => {
  const now = Date.now();
  const devices = visibleUnits()
    .map(unit => ({
      id: unit.id,
      tabletId: unit.tabletId,
      department: unit.department,
      online: now - Number(unit.timestamp || 0) <= 180000,
      lastSeen: unit.timestamp || null,
      app: unit.appId === CURRENT_TRACKER_APP_ID ? "nueva" : "anterior",
      appVersion: unit.appVersion || "",
      lat: unit.lat,
      lng: unit.lng
    }))
    .sort((a, b) => Number(b.lastSeen || 0) - Number(a.lastSeen || 0));

  res.json({ devices });
});

app.get("/api/departments", (req, res) => {
  const departments = [
    ...new Set([
      ...deviceDepartments.departments,
      ...visibleUnits().map(unit => unit.department),
      "Sin asignar"
    ].filter(Boolean))
  ].sort((a, b) => a.localeCompare(b));

  res.json({ departments });
});

app.post("/api/devices/department", (req, res) => {
  const id = String(req.body?.id || "").trim();
  const department = String(req.body?.department || "Sin asignar").trim() || "Sin asignar";

  if (!id) {
    return res.status(400).json({ ok: false, error: "Unidad requerida" });
  }

  const entry = Object.entries(unidades).find(([key, unit]) =>
    normalizeName(key) === normalizeName(id)
    || normalizeName(unit.id) === normalizeName(id)
    || normalizeName(unit.tabletId) === normalizeName(id)
  );
  const key = entry?.[0] || id;
  const unit = entry?.[1];
  const displayName = unit?.id || id;

  deviceDepartments.devices[key] = department;
  deviceDepartments.devices[displayName] = department;
  saveDeviceDepartments();

  if (unit) {
    unidades[key] = enrichUnit(unit, key);
    scheduleCurrentUnitsSave();
    if (shouldShowUnitId(unidades[key].id)) {
      io.emit("actualizarCoordenadas", unidades[key]);
    }
  }

  res.json({ ok: true, id: displayName, tabletId: key, department });
});

app.delete("/api/devices/:identifier", (req, res) => {
  const identifier = normalizeName(req.params.identifier);
  const matches = Object.entries(unidades).filter(([key, unit]) => {
    const enriched = enrichUnit(unit, key);
    return normalizeName(key) === identifier
      || normalizeName(enriched.id) === identifier
      || normalizeName(enriched.tabletId) === identifier;
  });

  if (!matches.length) {
    return res.status(404).json({ ok: false, error: "Unidad no encontrada" });
  }

  const removed = [];
  matches.forEach(([key, unit]) => {
    const enriched = enrichUnit(unit, key);
    removed.push(enriched.id);
    delete unidades[key];
    delete sesiones[key];
    Object.entries(activeAlerts).forEach(([alertId, alert]) => {
      if (
        normalizeName(alert.tabletId) === normalizeName(enriched.id) ||
        normalizeName(alert.sourceTabletId) === normalizeName(enriched.tabletId)
      ) {
        delete activeAlerts[alertId];
      }
    });
    delete deviceDepartments.devices[key];
    delete deviceDepartments.devices[enriched.id];
    delete deviceDepartments.devices[enriched.tabletId];
    io.emit("unitRemoved", { id: enriched.id });
  });

  saveDeviceDepartments();
  fs.writeFileSync(CURRENT_UNITS_FILE, JSON.stringify(unidades, null, 2));
  res.json({ ok: true, removed });
});

// ======================= POZOS =======================
app.get("/api/pozos", (req, res) => {
  const pozos = loadPozos();
  res.json({ pozos });
});

app.get("/api/sites/catalog", (req, res) => {
  const pozos = loadPozos();

  const sites = Object.values(SITE_CATALOG).map(site => {
    const match = findSiteCoordinates(site, pozos);
    return {
      id: site.id,
      type: site.type,
      name: site.name,
      table: site.table,
      lat: match?.lat ?? null,
      lng: match?.lng ?? null
    };
  });

  res.json({ sites });
});

app.get("/api/sites/:siteId/live", async (req, res) => {
  const siteId = String(req.params.siteId || "").trim().toLowerCase();
  const site = SITE_CATALOG[siteId];

  if (!site) {
    return res.status(404).json({ ok: false, error: "Sitio no encontrado" });
  }

  try {
    const snapshot = await buildSiteTelemetrySnapshot(siteId);
    res.json({
      ok: true,
      site: snapshot,
      dbEnabled: dbTelemetryEnabled()
    });
  } catch (err) {
    res.json({
      ok: true,
      warning: err.message,
      site: normalizedSiteTelemetry(site, site.sample, "piloto")
    });
  }
});

// ======================= RECORRIDO DEL DÃA =======================
app.get("/api/recorrido-dia", (req, res) => {
  const { fecha } = req.query;
  const maxPoints = Math.max(0, Number(req.query.maxPoints || 0));

  const fechaFinal = fecha || new Date().toISOString().split("T")[0];

  const fileNuevo = path.join(__dirname, `recorridos_${fechaFinal}.json`);
  const fileViejo = path.join(__dirname, "recorridos.json");

  try {
    // ðŸŸ¢ 1. intentar archivo por dÃ­a (nuevo sistema)
    if (fs.existsSync(fileNuevo)) {
      const data = JSON.parse(fs.readFileSync(fileNuevo, "utf8"));
      return res.json({ data: prepareRecorridosResponse(Object.values(data), maxPoints) });
    }

    // ðŸŸ¡ 2. fallback al archivo viejo
    if (fs.existsSync(fileViejo)) {
      const data = JSON.parse(fs.readFileSync(fileViejo, "utf8"));

      const filtrado = Object.values(data).filter(
        r => r.fecha === fechaFinal
      );

      return res.json({ data: prepareRecorridosResponse(filtrado, maxPoints) });
    }

    // ðŸ”´ 3. si no hay nada
    return res.json({ data: [] });

  } catch (err) {
    console.error("Error leyendo archivos:", err);
    res.status(500).json({ data: [] });
  }
});

function prepareRecorridosResponse(items, maxPoints = 0) {
  if (!maxPoints) return items;
  return items.map(item => ({
    ...item,
    recorrido: downsampleRoute(Array.isArray(item.recorrido) ? item.recorrido : [], maxPoints)
  }));
}

function downsampleRoute(points, maxPoints) {
  if (points.length <= maxPoints || maxPoints < 2) return points;
  const result = [points[0]];
  const step = (points.length - 2) / (maxPoints - 2);
  for (let i = 1; i < maxPoints - 1; i += 1) {
    result.push(points[Math.round(i * step)]);
  }
  result.push(points[points.length - 1]);
  return result;
}
// ======================= GEOCODE =======================

let lastRequestTime = 0;

app.get('/api/geocode', async (req, res) => {
  const { lat, lng } = req.query;

  if (!lat || !lng) {
    return res.json({ direccion: "Sin coordenadas" });
  }

  const key = Number(lat).toFixed(5) + "," + Number(lng).toFixed(5);

  // ================= CACHE =================
  if (cacheGeo[key]) {
    return res.json({ direccion: cacheGeo[key] });
  }

  // ================= RATE LIMIT =================
  const now = Date.now();

  if (now - lastRequestTime < 1000) {
    return res.json({ direccion: "Consultando..." });
  }

  lastRequestTime = now;

  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`,
      {
        headers: {
          'User-Agent': 'tracking-app'
        }
      }
    );

    if (!response.ok) {
      console.log("âš ï¸ Nominatim bloqueÃ³ la peticiÃ³n");
      return res.json({ direccion: "Sin direcciÃ³n" });
    }

    const data = await response.json();

    const direccion = data.display_name || "Sin direcciÃ³n";

    // ðŸ”¥ GUARDAR EN CACHE
    cacheGeo[key] = direccion;

    // ðŸ”¥ GUARDAR EN ARCHIVO
    guardarCacheGeo();

    res.json({ direccion });

  } catch (error) {
    console.log("âŒ Error geocode:", error.message);
    res.json({ direccion: "Sin direcciÃ³n" });
  }
});
// ======================= LIMPIEZA HISTÃ“RICO =======================
function limpiarHistorial() {
  const fechasUnicas = [
    ...new Set(Object.values(recorridosDia).map(r => r.fecha))
  ].sort();

  if (fechasUnicas.length <= 60) return;

  const fechasAEliminar = fechasUnicas.slice(0, 30);

  Object.keys(recorridosDia).forEach(key => {
    const registro = recorridosDia[key];

    if (fechasAEliminar.includes(registro.fecha)) {
      console.log(`ðŸ—‘ Eliminando bloque antiguo: ${key}`);
      delete recorridosDia[key];
    }
  });
}

// ======================= CSV =======================
function loadTabletsFromCSV(callback) {
  const tablets = {};
  const filePath = path.join(__dirname, 'tablets.csv');

  if (!fs.existsSync(filePath)) return callback(null, tablets);

  fs.createReadStream(filePath)
    .pipe(csv())
    .on('data', (row) => {
      const lat = parseFloat(row.lat);
      const lng = parseFloat(row.lng || row.lon);

      if (!isNaN(lat) && !isNaN(lng)) {
        tablets[row.tabletId] = {
          id: row.tabletId,
          lat,
          lng,
          timestamp: Date.now()
        };
      }
    })
    .on('end', () => callback(null, tablets))
    .on('error', callback);
}

function saveTabletsToCSV(tablets, callback) {
  const filePath = path.join(__dirname, 'tablets.csv');

  const csvWriter = createCsvWriter({
    path: filePath,
    header: [
      { id: 'tabletId', title: 'tabletId' },
      { id: 'lat', title: 'lat' },
      { id: 'lng', title: 'lng' }
    ]
  });

  const records = Object.values(tablets).map(u => ({
    tabletId: u.id,
    lat: u.lat,
    lng: u.lng
  }));

  csvWriter.writeRecords(records)
    .then(() => callback(null))
    .catch(callback);
}

let pozosCache = [];

function loadPozos() {
  const filePath = path.join(__dirname, 'pozos.csv');

  if (!fs.existsSync(filePath)) return [];

  const data = fs.readFileSync(filePath, 'utf8');

  const lines = data.split('\n').slice(1);

  return lines.map(line => {
    const [pozo, lat, lng] = line.split(';');

    return {
      nombre: pozo,
      lat: parseFloat(lat),
      lng: parseFloat(lng)
    };
  }).filter(p => !isNaN(p.lat) && !isNaN(p.lng));
}

// cargar una vez
pozosCache = loadPozos();

function normalizeTimestamp(value) {
  if (value === undefined || value === null || value === "") {
    return Date.now();
  }

  const numeric = Number(value);
  if (!Number.isNaN(numeric)) {
    return numeric > 100000000000 ? numeric : numeric * 1000;
  }

  const parsed = Date.parse(value);
  return Number.isNaN(parsed) ? Date.now() : parsed;
}

function distancia(p1, p2) {
  const R = 6371000;

  const dLat = (p2.lat - p1.lat) * Math.PI / 180;
  const dLng = (p2.lng - p1.lng) * Math.PI / 180;

  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(p1.lat * Math.PI / 180) *
    Math.cos(p2.lat * Math.PI / 180) *
    Math.sin(dLng / 2) ** 2;

  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)));
}

function isPlausibleLocation(tabletId, lat, lng, timestamp) {
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return false;
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) return false;

  const previous = lastGoodLocations[tabletId];
  if (!previous) {
    lastGoodLocations[tabletId] = { lat, lng, timestamp, rejects: 0 };
    return true;
  }

  const elapsedSeconds = Math.max((timestamp - previous.timestamp) / 1000, 1);
  const distance = distancia(previous, { lat, lng });
  const speedMps = distance / elapsedSeconds;
  const hardJump = distance > 1200 && elapsedSeconds < 120;
  const implausibleSpeed = speedMps > 45;

  if (hardJump || implausibleSpeed) {
    previous.rejects = (previous.rejects || 0) + 1;
    if (previous.rejects < 3) {
      console.log(`Punto descartado por salto: ${tabletId} ${distance.toFixed(0)}m ${speedMps.toFixed(1)}m/s`);
      return false;
    }
  }

  lastGoodLocations[tabletId] = { lat, lng, timestamp, rejects: 0 };
  return true;
}

function estaEnPozo(punto) {
  for (let pozo of pozosCache) {
    const d = distancia(punto, pozo);

    if (d < 30) {
      return pozo;
    }
  }
  return null;
}

function appendV2IngestLog(records) {
  if (!records.length) return;

  const lines = records.map(record => JSON.stringify(record)).join("\n") + "\n";
  fs.appendFileSync(V2_INGEST_FILE, lines);
}

function processLocation(data, source = "mqtt") {
  if (CURRENT_APP_ONLY && data.appId !== CURRENT_TRACKER_APP_ID) {
    return {
      tabletId: data.tabletId,
      source,
      skipped: true,
      reason: "legacy_app"
    };
  }

  if (
    !data.tabletId ||
    data.lat === undefined ||
    (data.lng === undefined && data.lon === undefined)
  ) {
    throw new Error("Mensaje invalido");
  }

  const lat = parseFloat(data.lat);
  const lng = parseFloat(data.lng || data.lon);

  if (isNaN(lat) || isNaN(lng)) {
    throw new Error("Coordenadas invalidas");
  }

  const now = normalizeTimestamp(data.timestamp || data.time || data.createdAt);
  if (!isPlausibleLocation(data.tabletId, lat, lng, now)) {
    return {
      tabletId: data.tabletId,
      lat,
      lng,
      timestamp: now,
      source,
      skipped: true
    };
  }

  const fechaHoy = new Date(now).toISOString().split("T")[0];
  const key = data.tabletId + "_" + fechaHoy;

  if (!recorridosDia[key]) {
    recorridosDia[key] = {
      unidad: data.tabletId,
      fecha: fechaHoy,
      recorrido: [],
      eventos: [],
      estado: null
    };

    console.log(`Nuevo recorrido del dia: ${key}`);
  }

  recorridosDia[key].recorrido.push({
    lat,
    lng,
    timestamp: now
  });

  if (recorridosDia[key].recorrido.length > 2000) {
    recorridosDia[key].recorrido.shift();
  }

  const recorrido = recorridosDia[key].recorrido;
  const len = recorrido.length;

  if (len > 2) {
    const actual = recorrido[len - 1];
    const anterior = recorrido[len - 2];
    const dist = distancia(actual, anterior);

    if (dist < 5) {
      if (!recorridosDia[key].estado) {
        const pozo = estaEnPozo(actual);

        recorridosDia[key].estado = {
          inicio: actual.timestamp,
          lat: actual.lat,
          lng: actual.lng,
          pozo
        };
      }
    } else {
      const estado = recorridosDia[key].estado;

      if (estado) {
        const duracion = actual.timestamp - estado.inicio;

        if (estado.pozo && duracion > 3 * 60 * 1000) {
          recorridosDia[key].eventos.push({
            tipo: "pozo",
            nombre: estado.pozo.nombre,
            lat: estado.lat,
            lng: estado.lng,
            inicio: estado.inicio,
            fin: actual.timestamp
          });

          console.log(`Visita a pozo: ${estado.pozo.nombre}`);
        } else if (!estado.pozo && duracion > 20 * 60 * 1000) {
          recorridosDia[key].eventos.push({
            tipo: "tiempo_muerto",
            lat: estado.lat,
            lng: estado.lng,
            inicio: estado.inicio,
            fin: actual.timestamp
          });

          console.log("Tiempo muerto detectado");
        }

        recorridosDia[key].estado = null;
      }
    }
  }

  if (!sesiones[data.tabletId]) {
    sesiones[data.tabletId] = {
      unidad: data.tabletId,
      inicio: new Date(now),
      fin: null,
      recorrido: []
    };

    console.log(`Nueva sesion iniciada: ${data.tabletId}`);
  }

  sesiones[data.tabletId].recorrido.push({
    lat,
    lng,
    timestamp: now
  });

  const displayName = nombresUnidades[data.tabletId] || data.tabletId;
  if (!shouldShowUnitId(displayName)) {
    return {
      tabletId: data.tabletId,
      lat,
      lng,
      timestamp: now,
      source,
      hidden: true
    };
  }

  unidades[data.tabletId] = {
    id: displayName,
    tabletId: data.tabletId,
    department: unitDepartment(data.tabletId, displayName),
    lat,
    lng,
    timestamp: now,
    source,
    appId: data.appId,
    appVersion: data.appVersion || "",
    appVersionCode: data.appVersionCode || null
  };

  scheduleCurrentUnitsSave();
  if (shouldShowUnitId(unidades[data.tabletId].id)) {
    io.emit('actualizarCoordenadas', unidades[data.tabletId]);
  }

  return {
    tabletId: data.tabletId,
    lat,
    lng,
    timestamp: now,
    source
  };
}

app.post("/api/v2/locations/batch", (req, res) => {
  if (TRACKING_MODE === "legacy") {
    return res.status(503).json({
      ok: false,
      error: "El modo legacy esta activo. MQTT sigue funcionando."
    });
  }

  const body = req.body || {};
  const defaultTabletId = body.tabletId || body.deviceId;
  const token = req.headers["x-device-token"] || body.token;

  if (!isValidDeviceToken(defaultTabletId, token)) {
    return res.status(401).json({ ok: false, error: "Token invalido" });
  }

  const points = Array.isArray(body.points)
    ? body.points
    : Array.isArray(body.locations)
      ? body.locations
      : [];

  if (!points.length) {
    return res.status(400).json({ ok: false, error: "Sin puntos para procesar" });
  }

  if (points.length > MAX_BATCH_POINTS) {
    return res.status(413).json({
      ok: false,
      error: `Maximo ${MAX_BATCH_POINTS} puntos por lote`
    });
  }

  const accepted = [];
  const rejected = [];
  const logRecords = [];

  points.forEach((point, index) => {
    try {
      const tabletId = point.tabletId || point.deviceId || defaultTabletId;
      const normalized = {
        ...point,
        tabletId,
        appId: point.appId || body.appId,
        appVersion: point.appVersion || body.appVersion,
        appVersionCode: point.appVersionCode || body.appVersionCode
      };

      if (!isValidDeviceToken(tabletId, token)) {
        throw new Error("Token invalido para dispositivo");
      }

      const processed = processLocation(normalized, "api-v2");
      accepted.push({
        index,
        timestamp: processed.timestamp
      });
      logRecords.push({
        receivedAt: Date.now(),
        ...processed,
        accuracy: point.accuracy,
        speed: point.speed,
        battery: point.battery,
        seq: point.seq
      });
    } catch (err) {
      rejected.push({
        index,
        error: err.message
      });
    }
  });

  try {
    appendV2IngestLog(logRecords);
  } catch (err) {
    console.log("Error guardando log v2:", err.message);
  }

  res.json({
    ok: rejected.length === 0,
    accepted: accepted.length,
    rejected
  });
});

app.get("/api/v2/health", (req, res) => {
  res.json({
    ok: true,
    mode: TRACKING_MODE,
    mqttEnabled: TRACKING_MODE !== "new",
    mqttConnected: Boolean(mqttClient?.connected),
    mqttStatus,
    apiV2Enabled: TRACKING_MODE !== "legacy",
    tokenDevices: Object.keys(deviceTokens).length,
    unitsOnline: Object.values(unidades).filter(unit => Date.now() - Number(unit.timestamp || 0) <= 180000).length
  });
});

app.get("/api/app-update/operatividad", (req, res) => {
  let manifest = {
    app: "operatividad",
    versionCode: 16,
    versionName: "1.15",
    notes: "Version 1.15: actualizaciones publicas mediante GitHub, reconexion de mensajes y sincronizacion de ubicaciones pendientes.",
    required: false
  };

  try {
    if (fs.existsSync(APP_UPDATE_MANIFEST_FILE)) {
      manifest = { ...manifest, ...JSON.parse(fs.readFileSync(APP_UPDATE_MANIFEST_FILE, "utf8")) };
    }
  } catch (err) {
    console.log("Error leyendo app_update_manifest.json:", err.message);
  }

  const baseUrl = process.env.APP_UPDATE_BASE_URL || `${req.protocol}://${req.get("host")}`;
  res.json({
    ...manifest,
    apkUrl: manifest.apkUrl || `${baseUrl}/apks/operatividad.apk`
  });
});

app.get("/api/alerts/active", (req, res) => {
  res.json({ alerts: Object.values(activeAlerts) });
});

app.get("/api/messages/recent", (req, res) => {
  const limit = req.query.limit;
  const replies = filterDeletedMessageRecords("replies", readRecentNdjson(MESSAGE_REPLIES_FILE, limit));
  const messages = filterDeletedMessageRecords("messages", readRecentNdjson(MESSAGES_FILE, limit));

  res.json({
    messages: applyReadReceiptsToMessages(messages, replies),
    replies,
    destinations: filterDeletedMessageRecords("destinations", readRecentNdjson(DESTINATIONS_FILE, limit))
  });
});

app.get("/api/reports/order-closures", (req, res) => {
  const limit = req.query.limit;
  res.json({
    ok: true,
    reports: readRecentNdjson(ORDER_CLOSE_REPORTS_FILE, limit)
  });
});

app.get("/api/evidences/:fileName", (req, res) => {
  const fileName = path.basename(String(req.params.fileName || ""));
  const filePath = path.join(EVIDENCE_DIR, fileName);
  if (!fileName || !fs.existsSync(filePath)) {
    return res.status(404).json({ ok: false, error: "Evidencia no encontrada" });
  }
  res.sendFile(filePath);
});

app.post(
  "/api/evidences/upload",
  express.raw({ type: ["image/jpeg", "application/octet-stream"], limit: "8mb" }),
  (req, res) => {
    try {
      const token = String(req.get("x-jmas-evidence-token") || req.query.token || "");
      if (token !== EVIDENCE_UPLOAD_TOKEN) {
        return res.status(401).json({ ok: false, error: "No autorizado" });
      }

      const evidence = saveEvidenceRecord(
        {
          ...req.query,
          mimeType: req.get("content-type") || "image/jpeg"
        },
        Buffer.isBuffer(req.body) ? req.body : Buffer.alloc(0)
      );
      res.json({ ok: true, evidence });
    } catch (err) {
      res.status(400).json({ ok: false, error: err.message || "No se pudo guardar evidencia" });
    }
  }
);

app.post("/api/messages/delete", (req, res) => {
  const type = String(req.body?.type || "").trim();
  const ids = Array.isArray(req.body?.ids)
    ? req.body.ids.map(id => String(id || "").trim()).filter(Boolean)
    : [];

  if (!["messages", "replies", "destinations"].includes(type)) {
    return res.status(400).json({ ok: false, error: "Tipo de mensaje invalido" });
  }

  if (!ids.length) {
    return res.json({ ok: true, deleted: 0 });
  }

  const current = new Set(messageDeletions[type] || []);
  ids.forEach(id => current.add(id));
  messageDeletions[type] = [...current].slice(-1000);
  saveMessageDeletions();

  res.json({ ok: true, deleted: ids.length });
});

app.post("/api/alerts/:alertId/close", (req, res) => {
  const alertId = req.params.alertId;
  let existing = activeAlerts[alertId];
  let storageKey = alertId;

  if (!existing) {
    const match = Object.entries(activeAlerts).find(([, alert]) =>
      alert.id === alertId || alert.tabletId === alertId || alert.sourceTabletId === alertId
    );
    if (match) {
      storageKey = match[0];
      existing = match[1];
    }
  }

  if (!existing) {
    return res.status(404).json({ ok: false, error: "Alerta no encontrada" });
  }

  const closed = {
    ...existing,
    status: "closed",
    closedAt: Date.now(),
    closedBy: req.body?.closedBy || "central",
    closeReason: req.body?.reason || "Cerrada desde mapa"
  };

  delete activeAlerts[storageKey];
  saveActiveAlerts();
  appendAlertEvent({ event: "closed", ...closed });

  io.emit("emergencyClosed", closed);

  res.json({ ok: true, alert: closed });
});

app.post("/api/messages/send", (req, res) => {
  const target = String(req.body?.target || "all").trim();
  const type = String(req.body?.type || "general").trim();
  const text = String(req.body?.text || "").trim();
  const fromName = String(req.body?.fromName || "central").trim();

  if (!text) {
    return res.status(400).json({ ok: false, error: "Mensaje requerido" });
  }

  if (!mqttClient || !mqttClient.connected) {
    return res.status(503).json({ ok: false, error: "MQTT no esta conectado" });
  }

  const targetAliases = resolveTargetAliases(target);
  const message = {
    messageId: `msg-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    target: targetAliases.target,
    targetTabletId: targetAliases.targetTabletId,
    targetName: targetAliases.targetName,
    type: type || "general",
    from: fromName || "central",
    text,
    timestamp: Date.now()
  };

  mqttClient.publish("tablet/message", JSON.stringify(message), { qos: 1 }, (err) => {
    if (err) {
      return res.status(500).json({ ok: false, error: err.message });
    }

    appendOperationalMessage(message);
    io.emit("operationalMessage", message);
    res.json({ ok: true, message });
  });
});

app.post("/api/destinations/send", async (req, res) => {
  const target = String(req.body?.target || "all").trim();
  const name = String(req.body?.name || "Destino operativo").trim();
  const note = String(req.body?.note || "").trim();
  const siteId = String(req.body?.siteId || "").trim().toLowerCase();
  const lat = parseFloat(req.body?.lat);
  const lng = parseFloat(req.body?.lng);

  if (isNaN(lat) || isNaN(lng)) {
    return res.status(400).json({ ok: false, error: "Coordenadas requeridas" });
  }

  if (!mqttClient || !mqttClient.connected) {
    return res.status(503).json({ ok: false, error: "MQTT no esta conectado" });
  }

  const targetAliases = resolveTargetAliases(target);
  const siteTelemetry = await buildSiteTelemetrySnapshot(siteId);
  const destination = {
    destinationId: `dst-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    target: targetAliases.target,
    targetTabletId: targetAliases.targetTabletId,
    targetName: targetAliases.targetName,
    status: "active",
    name,
    note,
    lat,
    lng,
    siteId: siteTelemetry?.id || siteId || "",
    siteTelemetry,
    from: "central",
    timestamp: Date.now()
  };

  mqttClient.publish("tablet/destination", JSON.stringify(destination), { qos: 1 }, (err) => {
    if (err) {
      return res.status(500).json({ ok: false, error: err.message });
    }

    appendOperationalDestination(destination);
    destinationTasks[destination.destinationId] = destination;
    saveDestinationTasks();
    io.emit("operationalDestination", destination);
    io.emit("destinationTasks", activeDestinationTasks());
    res.json({ ok: true, destination });
  });
});

app.get("/api/destinations/tasks", (req, res) => {
  res.json({ tasks: activeDestinationTasks() });
});

app.post("/api/destinations/tasks/:destinationId/complete", (req, res) => {
  const destinationId = req.params.destinationId;
  const task = destinationTasks[destinationId];

  if (!task) {
    return res.status(404).json({ ok: false, error: "Destino no encontrado" });
  }

  destinationTasks[destinationId] = {
    ...task,
    status: "completed",
    completedAt: Date.now(),
    completedBy: req.body?.completedBy || "central"
  };
  saveDestinationTasks();
  appendOperationalDestination({
    event: "completed",
    ...destinationTasks[destinationId]
  });

  io.emit("destinationTaskCompleted", destinationTasks[destinationId]);
  io.emit("destinationTasks", activeDestinationTasks());
  res.json({ ok: true, task: destinationTasks[destinationId] });
});

// ======================= MQTT =======================
if (TRACKING_MODE !== "new") {
mqttClient = mqtt.connect(MQTT_BROKER_URL, mqttConnectOptions());

mqttClient.on('connect', () => {
  mqttStatus.connected = true;
  mqttStatus.lastConnectAt = Date.now();
  mqttStatus.lastError = "";
  mqttClient.subscribe('tablet/alert', (err) => {
    if (!err) console.log('Suscrito a tablet/alert');
  });
  console.log('âœ… Conectado a MQTT Broker');

  mqttClient.subscribe('tablet/message/reply', (err) => {
    if (!err) console.log('Suscrito a tablet/message/reply');
  });

  mqttClient.subscribe('tablet/location', (err) => {
    if (!err) console.log('ðŸ“¡ Suscrito a tablet/location');
  });
});

mqttClient.on('message', (topic, message) => {
  try {
    mqttStatus.lastMessageAt = Date.now();
    mqttStatus.lastTopic = topic;
    const data = JSON.parse(message.toString());

    if (CURRENT_APP_ONLY && topic === 'tablet/location' && data.appId !== CURRENT_TRACKER_APP_ID) {
      return;
    }

    if (topic === 'tablet/alert') {
      const rawTabletId = data.tabletId;
      const lastKnown = unidades[rawTabletId] || unidades[nombresUnidades[rawTabletId]];
      const alertType = data.type || "emergency";
      const displayTabletId = nombresUnidades[rawTabletId] || rawTabletId;
      const alertId = alertStorageId(displayTabletId, alertType);
      const alert = {
        id: alertId,
        type: alertType,
        tabletId: displayTabletId,
        sourceTabletId: rawTabletId,
        lat: Number.isFinite(parseFloat(data.lat)) ? parseFloat(data.lat) : parseFloat(lastKnown?.lat),
        lng: Number.isFinite(parseFloat(data.lng || data.lon)) ? parseFloat(data.lng || data.lon) : parseFloat(lastKnown?.lng),
        timestamp: normalizeTimestamp(data.timestamp),
        message: data.message || (alertType === "emergency" ? "Emergencia" : "Alerta operativa")
      };

      if (!alert.tabletId) {
        console.log("Alerta invalida:", data);
        return;
      }

      if (isNaN(alert.lat) || isNaN(alert.lng)) {
        alert.lat = 31.7;
        alert.lng = -106.4;
        alert.address = "Sin ultima ubicacion disponible";
      }

      activeAlerts[alert.id] = {
        ...alert,
        status: "active",
        openedAt: Date.now()
      };
      saveActiveAlerts();
      appendAlertEvent({ event: "opened", ...activeAlerts[alert.id] });

      io.emit('emergencyAlert', activeAlerts[alert.id]);
      console.log(`ALERTA ${alert.tabletId} -> ${alert.lat}, ${alert.lng}`);
      return;
    }

    if (topic === 'tablet/message/reply') {
      if (data.type === "evidence") {
        const imageBase64 = String(data.imageBase64 || "").trim();

        if (!imageBase64) {
          console.log("Evidencia invalida:", { tabletId: data.tabletId, destinationId: data.destinationId, stage: data.stage });
          return;
        }

        const evidence = saveEvidenceRecord(data, Buffer.from(imageBase64, "base64"));
        console.log(`EVIDENCIA ${evidence.destinationId} ${evidence.tabletId}: ${evidence.stage}`);
        return;
      }

      if (data.type === "order_status") {
        const destinationId = String(data.destinationId || "").trim();
        const statusText = String(data.status || "").trim();
        const tabletId = data.tabletId || "";
        const task = destinationId ? destinationTasks[destinationId] : null;

        if (!destinationId || !statusText) {
          console.log("Estado de orden invalido:", data);
          return;
        }

        const completed = /^finaliz/i.test(statusText) || /^completed$/i.test(statusText);
        destinationTasks[destinationId] = {
          ...(task || {}),
          destinationId,
          folio: data.folio || task?.folio || "",
          platform: data.platform || task?.platform || "Tracking",
          progressStatus: statusText,
          status: completed ? "completed" : (task?.status || "active"),
          updatedAt: normalizeTimestamp(data.timestamp),
          updatedBy: tabletId,
          ...(completed ? {
            completedAt: normalizeTimestamp(data.timestamp),
            completedBy: tabletId
          } : {})
        };
        saveDestinationTasks();

        const statusEvent = {
          type: "order_status",
          tabletId,
          destinationId,
          folio: data.folio || "",
          platform: data.platform || "Tracking",
          status: statusText,
          timestamp: normalizeTimestamp(data.timestamp)
        };
        appendOperationalReply(statusEvent);
        io.emit("operationalReply", statusEvent);
        io.emit("destinationTasks", activeDestinationTasks());
        console.log(`ORDEN ${destinationId} ${tabletId}: ${statusText}`);
        return;
      }

      if (data.type === "order_close_report") {
        const destinationId = String(data.destinationId || "").trim();
        const tabletId = data.tabletId || "";
        const task = destinationId ? destinationTasks[destinationId] : null;

        if (!destinationId || !tabletId) {
          console.log("Reporte de cierre invalido:", data);
          return;
        }

        const report = saveOrderCloseReport(data);
        destinationTasks[destinationId] = {
          ...(task || {}),
          destinationId,
          folio: data.folio || task?.folio || "",
          platform: data.platform || task?.platform || "Tracking",
          progressStatus: "Finalizado",
          status: "completed",
          updatedAt: report.timestamp,
          updatedBy: tabletId,
          completedAt: report.timestamp,
          completedBy: tabletId,
          closeReportAt: report.timestamp
        };
        saveDestinationTasks();
        io.emit("destinationTasks", activeDestinationTasks());
        console.log(`REPORTE CIERRE ${destinationId} ${tabletId}`);
        return;
      }

      if (data.type === "read_receipt") {
        const receipt = {
          type: "read_receipt",
          tabletId: data.tabletId,
          messageId: data.messageId || "",
          readAt: normalizeTimestamp(data.readAt || data.timestamp),
          timestamp: normalizeTimestamp(data.timestamp)
        };

        if (!receipt.tabletId || !receipt.messageId) {
          console.log("Acuse de lectura invalido:", data);
          return;
        }

        appendOperationalReply(receipt);
        markOperationalMessageRead(receipt);
        io.emit("messageReadReceipt", receipt);
        console.log(`LEIDO ${receipt.tabletId}: ${receipt.messageId}`);
        return;
      }

      const reply = {
        type: "reply",
        tabletId: data.tabletId,
        messageId: data.messageId || "",
        text: String(data.text || "").trim(),
        timestamp: normalizeTimestamp(data.timestamp)
      };

      if (!reply.tabletId || !reply.text) {
        console.log("Respuesta invalida:", data);
        return;
      }

      appendOperationalReply(reply);
      io.emit("operationalReply", reply);
      console.log(`RESPUESTA ${reply.tabletId}: ${reply.text}`);
      return;
    }

    if (
      !data.tabletId ||
      data.lat === undefined ||
      (data.lng === undefined && data.lon === undefined)
    ) {
      console.log("âš ï¸ Mensaje invÃ¡lido:", data);
      return;
    }

    const lat = parseFloat(data.lat);
    const lng = parseFloat(data.lng || data.lon);

    if (isNaN(lat) || isNaN(lng)) {
      console.log("âš ï¸ Coordenadas invÃ¡lidas:", data);
      return;
    }

    const now = Date.now();

    if (!isPlausibleLocation(data.tabletId, lat, lng, now)) {
      return;
    }

   

// ======================= RECORRIDO POR DÃA =======================
const fechaHoy = new Date().toISOString().split("T")[0];
const key = data.tabletId + "_" + fechaHoy;

if (!recorridosDia[key]) {
  recorridosDia[key] = {
    unidad: data.tabletId,
    fecha: fechaHoy,
    recorrido: [],
    eventos: [],
    estado: null // ðŸ”¥ importante
  };

  console.log(`ðŸ“˜ Nuevo recorrido del dÃ­a: ${key}`);
}

// guardar punto
recorridosDia[key].recorrido.push({
  lat,
  lng,
  timestamp: now
});

// ðŸ”¥ LIMITAR TAMAÃ‘O
if (recorridosDia[key].recorrido.length > 2000) {
  recorridosDia[key].recorrido.shift();
}

// ======================= DETECCIÃ“N DE PARADA =======================
const recorrido = recorridosDia[key].recorrido;
const len = recorrido.length;

if (len > 2) {
  const actual = recorrido[len - 1];
  const anterior = recorrido[len - 2];

  const dist = distancia(actual, anterior);

  // ðŸ”´ DETENIDO
  if (dist < 5) {

    if (!recorridosDia[key].estado) {
      const pozo = estaEnPozo(actual);

      recorridosDia[key].estado = {
        inicio: actual.timestamp,
        lat: actual.lat,
        lng: actual.lng,
        pozo: pozo // null o objeto pozo
      };
    }

  } else {
    // ðŸ”µ SE MOVIÃ“ â†’ evaluar parada
    const estado = recorridosDia[key].estado;

    if (estado) {
      const duracion = actual.timestamp - estado.inicio;

      // ðŸ›¢ VISITA A POZO (â‰¥ 3 min)
      if (estado.pozo && duracion > 3 * 60 * 1000) {

        recorridosDia[key].eventos.push({
          tipo: "pozo",
          nombre: estado.pozo.nombre,
          lat: estado.lat,
          lng: estado.lng,
          inicio: estado.inicio,
          fin: actual.timestamp
        });

        console.log(`ðŸ›¢ Visita a pozo: ${estado.pozo.nombre}`);
      }

      // â± TIEMPO MUERTO (â‰¥ 20 min)
      else if (!estado.pozo && duracion > 20 * 60 * 1000) {

        recorridosDia[key].eventos.push({
          tipo: "tiempo_muerto",
          lat: estado.lat,
          lng: estado.lng,
          inicio: estado.inicio,
          fin: actual.timestamp
        });

        console.log("â± Tiempo muerto detectado");
      }

      recorridosDia[key].estado = null;
    }
  }
}

    // ======================= POZOS =======================

// ðŸ”¹ Cargar pozos desde CSV (separado por ;)
function loadPozos() {
  const filePath = path.join(__dirname, 'pozos.csv');

  if (!fs.existsSync(filePath)) return [];

  const data = fs.readFileSync(filePath, 'utf8');

  const lines = data.split('\n').slice(1); // quitar encabezado

  return lines.map(line => {
    const [pozo, lat, lng] = line.split(';');

    return {
      nombre: pozo,
      lat: parseFloat(lat),
      lng: parseFloat(lng)
    };
  }).filter(p => !isNaN(p.lat) && !isNaN(p.lng));
}



    // ======================= HISTORIAL =======================
    if (!sesiones[data.tabletId]) {
      sesiones[data.tabletId] = {
        unidad: data.tabletId,
        inicio: new Date(),
        fin: null,
        recorrido: []
      };

      console.log(`ðŸŸ¢ Nueva sesiÃ³n iniciada: ${data.tabletId}`);
    }

    sesiones[data.tabletId].recorrido.push({
      lat,
      lng,
      timestamp: now
    });

    function distancia(p1, p2) {
  const R = 6371000;

  const dLat = (p2.lat - p1.lat) * Math.PI / 180;
  const dLng = (p2.lng - p1.lng) * Math.PI / 180;

  const a =
    Math.sin(dLat/2)**2 +
    Math.cos(p1.lat*Math.PI/180) *
    Math.cos(p2.lat*Math.PI/180) *
    Math.sin(dLng/2)**2;

  return R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)));
}

function estaEnPozo(punto) {
  for (let pozo of pozosCache) {
    const d = distancia(punto, pozo);

    if (d < 30) {
      return pozo;
    }
  }
  return null;
}


    // ======================= TRACKING =======================
    const displayName = nombresUnidades[data.tabletId] || data.tabletId;
    if (!shouldShowUnitId(displayName)) {
      return;
    }

    unidades[data.tabletId] = {
  id: displayName,
  tabletId: data.tabletId,
  department: unitDepartment(data.tabletId, displayName),
  lat,
  lng,
  timestamp: now,
  source: "mqtt",
  appId: data.appId,
  appVersion: data.appVersion || "",
  appVersionCode: data.appVersionCode || null
};

    console.log(`ðŸ“ ${data.tabletId} â†’ ${lat}, ${lng}`);

    scheduleCurrentUnitsSave();
    if (shouldShowUnitId(unidades[data.tabletId].id)) {
      io.emit('actualizarCoordenadas', unidades[data.tabletId]);
    }

  } catch (err) {
    console.error('Error MQTT:', err.message);
    mqttStatus.lastError = err.message;
  }
});

mqttClient.on('reconnect', () => {
  mqttStatus.connected = false;
});

mqttClient.on('close', () => {
  mqttStatus.connected = false;
});

mqttClient.on('offline', () => {
  mqttStatus.connected = false;
});

mqttClient.on('error', (err) => {
  mqttStatus.connected = false;
  mqttStatus.lastError = err.message;
  console.error("Error MQTT:", err.message);
});
}

// ======================= HISTORIAL =======================

// ðŸ”¹ Obtener historial
app.get("/api/historial", (req, res) => {
  try {
    const filePath = path.join(__dirname, "visitas.json");

    if (!fs.existsSync(filePath)) {
      return res.json({ historial: [] });
    }

    const data = JSON.parse(fs.readFileSync(filePath, "utf8"));

    res.json({ historial: data });

  } catch (error) {
    console.error("Error leyendo historial:", error);
    res.status(500).json({ error: "Error al obtener historial" });
  }
});

// ðŸ”´ Cerrar sesiÃ³n manual
app.post("/api/cerrar", (req, res) => {
  const { tabletId } = req.body;

  if (!sesiones[tabletId]) {
    return res.status(400).json({ error: "No hay sesiÃ³n activa" });
  }

  sesiones[tabletId].fin = new Date();

  const filePath = path.join(__dirname, "visitas.json");

  let historial = [];
  if (fs.existsSync(filePath)) {
    historial = JSON.parse(fs.readFileSync(filePath, "utf8"));
  }

  historial.push(sesiones[tabletId]);

  fs.writeFileSync(filePath, JSON.stringify(historial, null, 2));

  console.log(`ðŸ’¾ SesiÃ³n guardada: ${tabletId}`);

  delete sesiones[tabletId];

  res.json({ ok: true });
});

// ðŸ”¥ CIERRE AUTOMÃTICO
setInterval(() => {
  const ahora = Date.now();

  Object.keys(sesiones).forEach(id => {
    const ultima = sesiones[id].recorrido.slice(-1)[0];
    if (!ultima) return;

    const diff = ahora - ultima.timestamp;

    if (diff > 120000) {
      console.log(`â¹ Cerrando sesiÃ³n automÃ¡tica: ${id}`);

      sesiones[id].fin = new Date();

      const filePath = path.join(__dirname, "visitas.json");

      let historial = [];
      if (fs.existsSync(filePath)) {
        historial = JSON.parse(fs.readFileSync(filePath, "utf8"));
      }

      historial.push(sesiones[id]);

      fs.writeFileSync(filePath, JSON.stringify(historial, null, 2));

      delete sesiones[id];
    }
  });

}, 30000);

// ======================= SOCKET =======================
io.on('connection', (socket) => {
  socket.emit('init', visibleUnits());
  socket.emit('activeAlerts', Object.values(activeAlerts));
  socket.emit('destinationTasks', activeDestinationTasks());
});

setInterval(() => {
  if (UNIT_RETENTION_MS <= 0) return;
  const cutoff = Date.now() - UNIT_RETENTION_MS;

  Object.entries(unidades).forEach(([key, unit]) => {
    if (Number(unit.timestamp || 0) < cutoff) {
      delete unidades[key];
      io.emit("unitRemoved", { id: unit.id || key });
      scheduleCurrentUnitsSave();
    }
  });
}, 30_000);

// ======================= AUTO SAVE =======================
setInterval(() => {
  limpiarHistorial();
  guardarRecorridos(); // ðŸ”¥ importantÃ­simo
}, 12 * 60 * 60 * 1000); // cada 12 horas

// ======================= LOAD CSV =======================
loadTabletsFromCSV((err, data) => {
  if (!err) {
    console.log("ðŸ“‚ Datos cargados desde CSV");
  }
});


// ======================= GEOCODE =======================
app.get('/api/geocode', async (req, res) => {
  const { lat, lng } = req.query;

  if (!lat || !lng) {
    return res.status(400).json({
      direccion: "Coordenadas invÃ¡lidas"
    });
  }

  try {
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`,
      {
        headers: {
          'User-Agent': 'tracking-app'
        }
      }
    );

    const data = await response.json();

    res.json({
      direccion: data.display_name || "DirecciÃ³n no disponible"
    });

  } catch (error) {
    console.error("âŒ Error geocode:", error.message);

    res.status(500).json({
      direccion: "Error obteniendo direcciÃ³n"
    });
  }
});

// ======================= START Servidor:  cd backend  server.js  http://192.168.100.199:3031/index.html =======================
const PORT = Number(process.env.PORT || 3031);

server.listen(PORT, '0.0.0.0', () => {
  console.log(`ðŸš€ Servidor corriendo en http://0.0.0.0:${PORT}`);
});
