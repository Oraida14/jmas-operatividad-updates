﻿// ================= MAPA =================
const map = L.map('map', {
  zoomControl: false
}).setView([31.7, -106.4], 12);

const streetLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19,
  attribution: '&copy; OpenStreetMap'
});

const satelliteLayer = L.tileLayer(
  'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
  {
    maxZoom: 19,
    attribution: 'Tiles &copy; Esri'
  }
);

let activeMapLayer = null;

function setMapLayer(layerName) {
  const nextLayerName = layerName === "satellite" ? "satellite" : "street";
  const nextLayer = nextLayerName === "satellite" ? satelliteLayer : streetLayer;

  if (activeMapLayer === nextLayer) return;
  if (activeMapLayer) map.removeLayer(activeMapLayer);
  nextLayer.addTo(map);
  activeMapLayer = nextLayer;

  localStorage.setItem("trackingMapLayer", nextLayerName);
  document.body.dataset.mapLayer = nextLayerName;
  setText("mapLayerToggle", nextLayerName === "satellite" ? "Mapa" : "Satélite");
}

function toggleMapLayer() {
  setMapLayer(activeMapLayer === satelliteLayer ? "street" : "satellite");
}

setMapLayer(localStorage.getItem("trackingMapLayer") || "street");

L.control.zoom({
  position: "bottomright"
}).addTo(map);

const unitMarkerLayer = typeof L.markerClusterGroup === "function"
  ? L.markerClusterGroup({
      showCoverageOnHover: false,
      spiderfyOnMaxZoom: true,
      disableClusteringAtZoom: 17,
      maxClusterRadius: 54
    })
  : L.layerGroup();
unitMarkerLayer.addTo(map);

// ================= SOCKET =================
const socket = io(window.location.origin, {
  transports: ["websocket"]
});

// ================= VARIABLES =================
let markers = {};
let posicionesPrevias = {};

let lista = document.getElementById("listaUnidades");
let unidadSeleccionada = null;

let velocidades = {};
let ultimaActualizacion = {};

let animacionesActivas = {};

let destinos = {};
let lastAcceptedPositions = {};

let bufferMinimo = 5;
let emergencyMarkers = {};
let activeEmergencyAlerts = {};
let emergencyPanelHidden = false;
let emergencySoundTimer = null;
let emergencyAddressCache = {};
let emergencyAddressLookupAt = {};
let messageTab = "replies";
let sentMessages = [];
let messageReplies = [];
let selectedDestination = null;
let destinationMarker = null;
let operationalAssets = [];
let siteCatalog = [];
let selectedSiteId = null;
let unitStates = {};
let selectedUnitData = null;
let destinationPickMode = false;
let unitAddressCache = {};
let activeDestinationTasks = [];
let closedReports = [];
let orderEvidences = {};
let stationaryLocks = {};
let activeOpsTab = "unit";
let departmentOptions = ["Sin asignar"];
let sendingOperationalMessage = false;
let sendingOperationalDestination = false;
let localMessageDeletions = loadLocalMessageDeletions();

function loadLocalMessageDeletions() {
  try {
    return {
      messages: [],
      replies: [],
      destinations: [],
      ...JSON.parse(localStorage.getItem("trackingDeletedMessages") || "{}")
    };
  } catch (_) {
    return { messages: [], replies: [], destinations: [] };
  }
}

function saveLocalMessageDeletions() {
  localStorage.setItem("trackingDeletedMessages", JSON.stringify(localMessageDeletions));
}

function rememberLocalDeletedMessages(type, ids) {
  const current = new Set(localMessageDeletions[type] || []);
  ids.filter(Boolean).forEach(id => current.add(id));
  localMessageDeletions[type] = [...current].slice(-1000);
  saveLocalMessageDeletions();
}

function filterLocalDeletedMessages(type, items) {
  const deleted = new Set(localMessageDeletions[type] || []);
  return items.filter(item => !deleted.has(messageRecordId(item, type === "messages" || type === "destinations" ? "sent" : "replies")));
}

function mergeUniqueById(existing, incoming, idKey) {
  const byId = new Map();
  [...incoming, ...existing].forEach(item => {
    const id = item?.[idKey] || item?.messageId || item?.destinationId || `${item?.timestamp}-${item?.text}`;
    if (id && !byId.has(id)) byId.set(id, item);
  });
  return [...byId.values()]
    .sort((a, b) => Number(b.timestamp || b.receivedAt || 0) - Number(a.timestamp || a.receivedAt || 0))
    .slice(0, 50);
}

function rememberOrderEvidence(evidence) {
  if (!evidence || evidence.type !== "evidence" || !evidence.destinationId) return;
  const key = evidence.destinationId;
  const stage = normalizeEvidenceStage(evidence.stage);
  if (!orderEvidences[key]) orderEvidences[key] = {};
  orderEvidences[key][stage] = {
    ...evidence,
    stage
  };
}

function normalizeEvidenceStage(stage) {
  const value = String(stage || "").trim().toLowerCase();
  if (value.startsWith("dur")) return "Durante";
  if (value.startsWith("desp")) return "Despues";
  return "Antes";
}

function messageRecordId(item, tab = messageTab) {
  if (!item) return "";
  if (tab === "sent" && item.type === "destino" && item.messageId) return `destination:${item.messageId}`;
  if (tab === "sent" && item.messageId) return `message:${item.messageId}`;
  if (item.type === "read_receipt") {
    return `receipt:${item.tabletId || ""}:${item.messageId || ""}:${item.readAt || item.timestamp || item.receivedAt || ""}`;
  }
  if (item.type === "reply") {
    return `reply:${item.tabletId || ""}:${item.messageId || ""}:${item.timestamp || item.receivedAt || ""}`;
  }
  return `${item.type || "item"}:${item.tabletId || item.target || ""}:${item.timestamp || item.receivedAt || ""}`;
}

function destinationAsSentMessage(destination) {
  return {
    messageId: destination.destinationId,
    target: destination.target,
    targetTabletId: destination.targetTabletId,
    targetName: destination.targetName,
    type: "destino",
    text: destination.note || destination.name || "Destino operativo",
    timestamp: destination.timestamp || destination.receivedAt || Date.now()
  };
}

async function loadRecentMessages() {
  try {
    const response = await fetch("/api/messages/recent?limit=100");
    const data = await response.json();
    const messages = filterLocalDeletedMessages("messages", Array.isArray(data.messages) ? data.messages : []);
    const replies = filterLocalDeletedMessages("replies", Array.isArray(data.replies) ? data.replies : []);
    const destinations = filterLocalDeletedMessages("destinations", Array.isArray(data.destinations) ? data.destinations : []);
    replies.forEach(rememberOrderEvidence);

    sentMessages = mergeUniqueById(
      sentMessages,
      [
        ...messages,
        ...destinations
          .filter(item => item.event !== "completed")
          .map(destinationAsSentMessage)
      ],
      "messageId"
    );
    messageReplies = mergeUniqueById(messageReplies, replies, "messageId");
    updateDashboardStats();
    renderMessageTray();
  } catch (error) {
    console.log("No se pudo cargar historial de mensajes:", error.message);
  }
}


// ================= ICONOS =================
const iconos = {
  "Eduardo Corral": "EduardoC.svg",
  "Aurelio Gerra": "Aurelio.svg",
  "JorgeVega": "JorgeVega.svg",
  "Ariel Avila": "HectorMons.svg",
  "Alejandro Ruiz": "DavidHdz.svg",
  "Salvador Duarte": "GustavoRamirez.svg",
  //"EduardoYepez": "Yepez.svg",
  //"EduardoZ": "EduardoZ.svg",
  //"JoseFelix": "JoseFelix.svg",
  //"DanielM": "DanielM.svg",
  //"JuanA": "JuanA.svg",  
  //"Jonathan": "Jonathan.svg",
  //"DavidH": "DavidH.svg",
  "Fabian Orona": "FabianC.svg",
  "Victor Vargas": "FabianC.svg",
  //"VictorCarrillo": "FabianC.svg",
  //"ID_TABLET": "ID_TABLET.svg",
  //"RafaGarcia": "RafaGarcia.svg",
  //"DanielPulgarin": "DanielPulgarin.svg",
  //"TinoCloro": "TinoCloro.svg",
  //"RonnyG": "RonnyG.svg",
  "Samsung": "Samsung.svg",
};

const DEFAULT_UNIT_ICON = "/img/FabianC.svg";


function irHistorial() {
  window.location.href = "/historial.html";
}
// ================= ICONO =================
function getIcon(id, online, angulo = 0) {

  let iconPath = iconos[id]
    ? `/img/${iconos[id]}`
    : DEFAULT_UNIT_ICON;

  const color = online ? "blue" : "red";

 return L.divIcon({
 html: `
  <div class="marker-container">

    <div class="label">${id}</div>

    <div class="vehiculo" style="transform: rotate(${angulo}deg);">
      <img src="${iconPath}" class="marker-img">
    </div>

  </div>
`,
  className: "",
  iconSize: [50, 50],
  iconAnchor: [25, 25],
  popupAnchor: [0, -30]
});
}

// ================= ÃNGULO =================
function calcularAngulo(lat1, lng1, lat2, lng2) {
  const dLon = (lng2 - lng1) * Math.PI / 180;
  lat1 = lat1 * Math.PI / 180;
  lat2 = lat2 * Math.PI / 180;

  const y = Math.sin(dLon) * Math.cos(lat2);
  const x = Math.cos(lat1) * Math.sin(lat2) -
            Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);

  let brng = Math.atan2(y, x);
  return (brng * 180 / Math.PI + 360) % 360;
}

function shouldAcceptPosition(id, lat, lng, timestamp) {
  if (isNaN(lat) || isNaN(lng)) return false;
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) return false;

  const previous = lastAcceptedPositions[id];
  if (!previous) {
    lastAcceptedPositions[id] = { lat, lng, timestamp: timestamp || Date.now(), rejects: 0 };
    return true;
  }

  const currentTime = timestamp || Date.now();
  const elapsedSeconds = Math.max((currentTime - previous.timestamp) / 1000, 1);
  const distance = L.latLng(previous.lat, previous.lng).distanceTo([lat, lng]);
  const speedMps = distance / elapsedSeconds;
  const isHardJump = distance > 1200 && elapsedSeconds < 120;
  const isImplausibleSpeed = speedMps > 45;

  if (isHardJump || isImplausibleSpeed) {
    previous.rejects = (previous.rejects || 0) + 1;
    if (previous.rejects < 3) return false;
  }

  lastAcceptedPositions[id] = { lat, lng, timestamp: currentTime, rejects: 0 };
  return true;
}

function normalizeStablePoint(id, lat, lng, timestamp) {
  const previous = lastAcceptedPositions[id];
  if (!previous) return { lat, lng };

  const distance = L.latLng(previous.lat, previous.lng).distanceTo([lat, lng]);
  if (distance < 18) {
    stationaryLocks[id] = {
      lat: previous.lat,
      lng: previous.lng,
      timestamp: timestamp || Date.now()
    };
    return { lat: previous.lat, lng: previous.lng };
  }

  delete stationaryLocks[id];
  return { lat, lng };
}

// ================= MOVIMIENTO SUAVE PRO =================
function moverSuave(id) {

  if (!markers[id] || !destinos[id] || destinos[id].length === 0) {
    animacionesActivas[id] = false;
    return;
  }

  animacionesActivas[id] = true;

  const marker = markers[id];
  const siguiente = destinos[id].shift();

  const from = marker.getLatLng();
  const to = L.latLng(siguiente.lat, siguiente.lng);

  // ðŸ”¥ distancia real entre puntos
  const distancia = from.distanceTo(to);

  // ðŸ”¥ duraciÃ³n dinÃ¡mica (CLAVE)
  // ðŸ”¥ usar tiempo real si existe
let duracion = 700;

if (siguiente.timestamp && ultimaActualizacion[id]) {
  duracion = siguiente.timestamp - ultimaActualizacion[id];
}

ultimaActualizacion[id] = siguiente.timestamp;

// ðŸ”’ lÃ­mites para evitar cosas raras
duracion = Math.max(300, Math.min(duracion, 2000));

  const start = performance.now();

  function frame(time) {

    const progress = Math.min((time - start) / duracion, 1);

    // ðŸ”¥ easing mejorado (mÃ¡s fluido que el anterior)
    const ease = 1 - Math.pow(1 - progress, 3);

    const lat = from.lat + (to.lat - from.lat) * ease;
    const lng = from.lng + (to.lng - from.lng) * ease;

    marker.setLatLng([lat, lng]);
    syncEmergencyMarker(id, lat, lng, false);

    if (progress < 1) {
      requestAnimationFrame(frame);
    } else {
      moverSuave(id); // ðŸ” sigue sin pausa
    }
  }

  requestAnimationFrame(frame);
}
// ================= INIT =================
socket.on("init", data => data.forEach(updateUnidad));

// ================= REALTIME =================
socket.on("actualizarCoordenadas", updateUnidad);
socket.on("unitRemoved", data => removeUnit(data?.id));
socket.on("emergencyAlert", showEmergencyAlert);
socket.on("activeAlerts", alerts => alerts.forEach(alert => showEmergencyAlert(alert, { silent: true })));
socket.on("emergencyClosed", closeEmergencyAlert);
socket.on("operationalMessage", showOperationalMessageStatus);
socket.on("operationalReply", showOperationalReply);
socket.on("orderEvidence", evidence => {
  rememberOrderEvidence(evidence);
  renderDestinationTasks();
  renderMessageTray();
});
socket.on("messageReadReceipt", showMessageReadReceipt);
socket.on("operationalDestination", showDestinationStatus);
socket.on("destinationTasks", tasks => {
  activeDestinationTasks = Array.isArray(tasks) ? tasks : [];
  renderDestinationTasks();
  updateDashboardStats();
});
socket.on("destinationTaskCompleted", task => {
  activeDestinationTasks = activeDestinationTasks.filter(item => item.destinationId !== task.destinationId);
  renderDestinationTasks();
  updateDashboardStats();
});
socket.on("orderCloseReport", report => {
  if (report) {
    closedReports = mergeUniqueById(closedReports, [report], "destinationId");
    renderClosedReports();
  }
});

map.on("click", event => {
  if (!destinationPickMode) return;
  selectOperationalDestination(event.latlng.lat, event.latlng.lng);
  setDestinationPickMode(false);
});

loadOperationalAssets();
loadDestinationTasks();
loadClosedReports();
initTheme();
startDashboardClock();
setFocusedUnit(null);

// ================= CONTROLES =================
function detenerSeguimiento() {
  unidadSeleccionada = null;
  selectedUnitData = null;
  setOperationalTargets("all");
  setDestinationPickMode(false);
  setFocusedUnit(null);

  document.querySelectorAll("li").forEach(li => {
    li.style.background = "";
    li.classList.remove("selected");
  });
  renderUnitDetail(null);
}

function startDashboardClock() {
  updateDashboardClock();
  setInterval(updateDashboardClock, 30000);
}

function updateDashboardClock() {
  const clock = document.getElementById("topClock");
  if (!clock) return;
  clock.textContent = new Date().toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit"
  });
}

function initTheme() {
  const savedTheme = localStorage.getItem("trackingTheme") || "dark";
  applyTheme(savedTheme);
}

function toggleTheme() {
  const nextTheme = document.body.dataset.theme === "light" ? "dark" : "light";
  localStorage.setItem("trackingTheme", nextTheme);
  applyTheme(nextTheme);
}

function applyTheme(theme) {
  document.body.dataset.theme = theme === "light" ? "light" : "dark";
  setText("themeLabel", theme === "light" ? "Claro" : "Oscuro");
}

function setOpsTab(tab) {
  activeOpsTab = tab || "unit";
  document.querySelectorAll("#opsTabs button").forEach(button => {
    button.classList.toggle("active", button.dataset.tab === activeOpsTab);
  });
  document.querySelectorAll("[data-ops-panel]").forEach(panel => {
    panel.classList.toggle("active", panel.dataset.opsPanel === activeOpsTab);
  });
  if (activeOpsTab === "tasks") renderDestinationTasks();
  if (activeOpsTab === "closed") renderClosedReports();
  if (activeOpsTab === "messages") renderMessageTray();
  if (activeOpsTab === "sites") refreshSelectedSite({ preferSearch: true });
}

function openTasksPanel() {
  setOpsTab("tasks");
  renderDestinationTasks();
}

function closeTasksPanel() {
  setOpsTab("unit");
}

async function loadDestinationTasks() {
  try {
    const res = await fetch("/api/destinations/tasks");
    const data = await res.json();
    activeDestinationTasks = Array.isArray(data.tasks) ? data.tasks : [];
    renderDestinationTasks();
    updateDashboardStats();
  } catch (err) {
    const list = document.getElementById("taskList");
    if (list) list.innerHTML = `<div class="message-empty">No se pudieron cargar tareas: ${escapeHtml(err.message)}</div>`;
  }
}

async function loadClosedReports() {
  const list = document.getElementById("closedReportList");
  try {
    const res = await fetch("/api/reports/order-closures?limit=50");
    const data = await res.json();
    closedReports = Array.isArray(data.reports) ? data.reports : [];
    renderClosedReports();
  } catch (err) {
    if (list) list.innerHTML = `<div class="message-empty">No se pudieron cargar reportes cerrados: ${escapeHtml(err.message)}</div>`;
  }
}

function renderClosedReports() {
  const list = document.getElementById("closedReportList");
  const summary = document.getElementById("closedReportSummary");
  if (!list) return;

  const reports = closedReports
    .slice()
    .sort((a, b) => Number(b.timestamp || b.receivedAt || 0) - Number(a.timestamp || a.receivedAt || 0));

  if (summary) {
    const units = new Set(reports.map(report => report.tabletId || "Unidad"));
    summary.innerHTML = `
      <div class="task-summary-grid">
        <div><span>Cerrados</span><strong>${reports.length}</strong></div>
        <div><span>Unidades</span><strong>${units.size}</strong></div>
      </div>
    `;
  }

  if (!reports.length) {
    list.innerHTML = `<div class="message-empty">Sin reportes cerrados. Cuando una tableta cierre un servicio aparecera aqui.</div>`;
    return;
  }

  list.innerHTML = reports.map(report => {
    const title = report.folio || report.name || report.destinationId || "Reporte cerrado";
    const closedAt = new Date(report.timestamp || report.receivedAt || Date.now()).toLocaleString();
    const timeline = report.timeline || {};
    const evidence = report.evidence || {};
    const note = report.note ? `<p>${escapeHtml(report.note)}</p>` : "";

    return `
      <div class="task-item closed-report">
        <div class="task-item-head">
          <strong>${escapeHtml(title)}</strong>
          <span>${escapeHtml(report.status || "Finalizado")}</span>
        </div>
        <div class="task-meta">
          <b>${escapeHtml(report.tabletId || "Unidad")}</b>
          <small>${escapeHtml(report.platform || "Tracking")} | ${closedAt}</small>
          ${report.orderType ? `<small>${escapeHtml(report.orderType)}</small>` : ""}
          ${report.address ? `<small>${escapeHtml(report.address)}</small>` : ""}
        </div>
        ${note}
        <div class="closed-report-timeline">
          ${closedTimelineItem("Recibido", timeline.receivedAt)}
          ${closedTimelineItem("En camino", timeline.enCaminoAt)}
          ${closedTimelineItem("En sitio", timeline.enSitioAt)}
          ${closedTimelineItem("En proceso", timeline.enProcesoAt)}
          ${closedTimelineItem("Finalizado", timeline.finalizadoAt || report.timestamp)}
        </div>
        <div class="task-evidence-strip">
          ${closedEvidenceItem("Antes", evidence.antes)}
          ${closedEvidenceItem("Durante", evidence.durante)}
          ${closedEvidenceItem("Despues", evidence.despues)}
        </div>
      </div>
    `;
  }).join("");
}

function closedTimelineItem(label, value) {
  if (!value) return `<small><span>${escapeHtml(label)}</span><b>Sin registro</b></small>`;
  const time = new Date(Number(value) || value).toLocaleString();
  return `<small><span>${escapeHtml(label)}</span><b>${escapeHtml(time)}</b></small>`;
}

function closedEvidenceItem(label, count) {
  const value = Number(count || 0);
  return `
    <div class="task-evidence ${value > 0 ? "ready" : "empty"}">
      <span>${escapeHtml(label)}</span>
      <strong>${value}</strong>
    </div>
  `;
}

function renderDestinationTasks() {
  const list = document.getElementById("taskList");
  const summary = document.getElementById("taskSummary");
  if (!list) return;

  const tasks = activeDestinationTasks.slice().sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
  if (summary) {
    const units = new Set(tasks.map(task => task.targetName || task.target || "Unidad"));
    summary.innerHTML = `
      <div class="task-summary-grid">
        <div><span>Activas</span><strong>${tasks.length}</strong></div>
        <div><span>Unidades</span><strong>${units.size}</strong></div>
      </div>
    `;
  }

  if (!tasks.length) {
    list.innerHTML = `<div class="message-empty">Sin destinos activos. Cuando envies un pozo o punto aparecera aqui.</div>`;
    return;
  }

  list.innerHTML = tasks.map(task => {
    const target = task.target === "all" ? "Todas las tabletas" : (task.targetName || task.target || task.targetTabletId || "Unidad");
    const time = new Date(task.timestamp || Date.now()).toLocaleString();
    const coords = `${Number(task.lat).toFixed(5)}, ${Number(task.lng).toFixed(5)}`;
    const note = task.note ? `<p>${escapeHtml(task.note)}</p>` : "";
    const progress = task.progressStatus || (task.status === "completed" ? "Finalizado" : "Activo");
    const evidences = evidenceStripHtml(task.destinationId);

    return `
      <div class="task-item">
        <div class="task-item-head">
          <strong>${escapeHtml(task.name || "Destino operativo")}</strong>
          <span>${escapeHtml(progress)}</span>
        </div>
        <div class="task-meta">
          <b>${escapeHtml(target)}</b>
          <small>${time}</small>
          <small>${coords}</small>
          ${task.updatedBy ? `<small>Ultimo estado: ${escapeHtml(task.updatedBy)} | ${new Date(task.updatedAt || Date.now()).toLocaleTimeString()}</small>` : ""}
        </div>
        ${note}
        ${evidences}
        <div class="task-actions">
          <button type="button" onclick="focusDestinationTask('${escapeAttribute(task.destinationId)}')">Ver mapa</button>
          <button type="button" onclick="completeDestinationTask('${escapeAttribute(task.destinationId)}')">Completar</button>
        </div>
      </div>
    `;
  }).join("");
}

function focusDestinationTask(destinationId) {
  const task = activeDestinationTasks.find(item => item.destinationId === destinationId);
  if (!task) return;
  map.setView([task.lat, task.lng], 16);
  selectOperationalDestination(Number(task.lat), Number(task.lng));
}

async function completeDestinationTask(destinationId) {
  const task = activeDestinationTasks.find(item => item.destinationId === destinationId);
  if (!task) return;

  const ok = window.confirm(`Marcar completado: ${task.name || "Destino operativo"}?`);
  if (!ok) return;

  try {
    const res = await fetch(`/api/destinations/tasks/${encodeURIComponent(destinationId)}/complete`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ completedBy: "central" })
    });
    const data = await res.json();

    if (!res.ok || !data.ok) {
      throw new Error(data.error || "No se pudo completar");
    }

    activeDestinationTasks = activeDestinationTasks.filter(item => item.destinationId !== destinationId);
    renderDestinationTasks();
    updateDashboardStats();
  } catch (err) {
    window.alert(`Error completando destino: ${err.message}`);
  }
}

function setFocusedUnit(id) {
  setText("focusedUnit", id ? `Unidad ${id}` : "Vista general");
}

function setOperationalTargets(target) {
  const value = target || "all";
  const messageTarget = document.getElementById("messageTarget");
  const destinationTarget = document.getElementById("destinationTarget");
  const replyContext = document.getElementById("replyContext");

  if (messageTarget) messageTarget.value = value;
  if (destinationTarget) destinationTarget.value = value;
  if (replyContext) {
    replyContext.textContent = value === "all"
      ? "Selecciona una respuesta o elige destino."
      : `Operando con ${value}`;
  }
}

function focusOpsPanel(mode) {
  const tab = mode === "destination" ? "dispatch" : mode === "tasks" ? "tasks" : mode === "sites" ? "sites" : "messages";
  setOpsTab(tab);
  const panel = document.querySelector(`[data-ops-panel="${tab}"]`);

  panel?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  panel?.classList.add("panel-focus");
  setTimeout(() => panel?.classList.remove("panel-focus"), 900);
}

function prepareMessageForSelectedUnit() {
  if (!selectedUnitData) return;
  setOperationalTargets(selectedUnitData.id);
  setMessageTab("replies");
  openMessagesPanel();
}

function prepareDestinationForSelectedUnit() {
  if (!selectedUnitData) return;
  setOperationalTargets(selectedUnitData.id);
  focusOpsPanel("destination");
}

function openMessagesPanel() {
  messageTab = "replies";
  renderMessageTray();
  setOpsTab("messages");
}

function closeMessagesPanel() {
  setOpsTab("unit");
}

function filterUnits() {
  const query = document.getElementById("unitSearch")?.value.trim().toLowerCase() || "";
  const department = document.getElementById("unitDepartmentFilter")?.value || "all";
  document.querySelectorAll("#listaUnidades li").forEach(item => {
    const matchesQuery = item.dataset.unit?.toLowerCase().includes(query);
    const matchesDepartment = department === "all" || item.dataset.department === department;
    item.style.display = matchesQuery && matchesDepartment ? "" : "none";
  });
}

async function loadDepartments() {
  try {
    const data = await fetch("/api/departments").then(res => res.json());
    departmentOptions = Array.isArray(data.departments) && data.departments.length
      ? data.departments
      : ["Sin asignar"];
    renderDepartmentFilters();
  } catch (_) {
    departmentOptions = ["Sin asignar"];
    renderDepartmentFilters();
  }
}

function registerDepartment(department) {
  const value = department || "Sin asignar";
  if (!departmentOptions.includes(value)) {
    departmentOptions.push(value);
    departmentOptions.sort((a, b) => a.localeCompare(b));
    renderDepartmentFilters();
  }
}

function renderDepartmentFilters() {
  const filters = [document.getElementById("unitDepartmentFilter")].filter(Boolean);
  filters.forEach(select => {
    const selected = select.value || "all";
    select.innerHTML = `<option value="all">Todos los departamentos</option>${departmentOptions.map(dept => `<option value="${escapeHtml(dept)}">${escapeHtml(dept)}</option>`).join("")}`;
    if ([...select.options].some(option => option.value === selected)) select.value = selected;
  });
}

function departmentSelectHtml(unit) {
  const selected = unit?.department || "Sin asignar";
  return `
    <select id="unitDepartmentSelect" onchange="saveUnitDepartment(decodeURIComponent('${encodeURIComponent(unit.id)}'), this.value)">
      ${departmentOptions.map(dept => `<option value="${escapeHtml(dept)}" ${dept === selected ? "selected" : ""}>${escapeHtml(dept)}</option>`).join("")}
    </select>
  `;
}

async function saveUnitDepartment(id, department) {
  try {
    const res = await fetch("/api/devices/department", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, department })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "No se pudo guardar");
    if (unitStates[id]) {
      unitStates[id].department = data.department;
      renderUnitDetail(unitStates[id]);
    }
    registerDepartment(data.department);
    filterUnits();
  } catch (error) {
    alert(error.message);
  }
}

function ensureMessageTarget(id) {
  const select = document.getElementById("messageTarget");
  const value = String(id);
  if (!id) return;

  [
    select,
    document.getElementById("messageFilter"),
    document.getElementById("destinationTarget")
  ].forEach(control => {
    if (!control) return;
    if ([...control.options].some(option => option.value === value)) return;

    const option = document.createElement("option");
    option.value = value;
    option.textContent = value;
    control.appendChild(option);
  });
}

async function loadOperationalAssets() {
  try {
    const [pozosRes, sitesRes] = await Promise.all([
      fetch("/api/pozos"),
      fetch("/api/sites/catalog")
    ]);
    const pozosData = await pozosRes.json();
    const sitesData = await sitesRes.json();
    operationalAssets = Array.isArray(pozosData.pozos) ? pozosData.pozos : [];
    siteCatalog = Array.isArray(sitesData.sites) ? sitesData.sites : [];

    const list = document.getElementById("assetList");
    if (!list) return;

    const options = [
      ...siteCatalog.map(site => ({
        value: site.id,
        label: `${site.name} (${site.type})`
      })),
      ...operationalAssets.map(asset => ({
        value: asset.nombre || "",
        label: "Catalogo CSV"
      }))
    ].filter(item => item.value);

    list.innerHTML = options.map(item => `
      <option value="${escapeHtml(item.value)}">${escapeHtml(item.label)}</option>
    `).join("");
  } catch (err) {
    const status = document.getElementById("destinationStatus");
    if (status) status.textContent = `No se pudo cargar catalogo: ${err.message}`;
  }
}

function useSelectedAsset() {
  const input = document.getElementById("assetSearch");
  const status = document.getElementById("destinationStatus");
  const query = input?.value.trim().toLowerCase() || "";
  if (!query) {
    if (status) status.textContent = "Escribe o selecciona un pozo del catalogo.";
    return;
  }

  const site = findSite(query);
  const asset = operationalAssets.find(item =>
    String(item.nombre || "").toLowerCase() === query
  ) || operationalAssets.find(item =>
    String(item.nombre || "").toLowerCase().includes(query)
  );

  if (!asset && !site) {
    if (status) status.textContent = "No encontre ese sitio en el catalogo.";
    return;
  }

  if (site) {
    selectedSiteId = site.id;
    setOpsTab("sites");
  }

  const nameInput = document.getElementById("destinationName");
  if (nameInput) nameInput.value = site?.name || asset?.nombre || "Destino operativo";

  const lat = parseFloat(asset?.lat ?? site?.lat);
  const lng = parseFloat(asset?.lng ?? site?.lng);
  if (!isNaN(lat) && !isNaN(lng)) {
    selectOperationalDestination(lat, lng);
    map.setView([lat, lng], 16);
  }

  if (status) {
    status.textContent = `Seleccionado: ${site?.name || asset?.nombre}${isNaN(lat) || isNaN(lng) ? " | sin coordenadas en catalogo" : ""}`;
  }
}

function handleAssetSearchInput() {
  selectedSiteId = null;
  const status = document.getElementById("siteLiveStatus");
  const detail = document.getElementById("siteLiveDetail");
  if (status && activeOpsTab === "sites") {
    status.textContent = "Presiona Actualizar para consultar el sitio escrito.";
  }
  if (detail && activeOpsTab === "sites") {
    detail.innerHTML = "";
  }
}

function findSite(query) {
  const normalized = String(query || "").trim().toLowerCase();
  if (!normalized) return null;
  return siteCatalog.find(site =>
    [site.id, site.name, site.table]
      .filter(Boolean)
      .some(value => String(value).toLowerCase() === normalized)
  ) || siteCatalog.find(site =>
    [site.id, site.name, site.table]
      .filter(Boolean)
      .some(value => String(value).toLowerCase().includes(normalized))
  );
}

async function refreshSelectedSite(options = {}) {
  const status = document.getElementById("siteLiveStatus");
  const detail = document.getElementById("siteLiveDetail");
  const query = document.getElementById("assetSearch")?.value || "";
  const siteFromSearch = findSite(query);
  const site = options.preferSearch && siteFromSearch
    ? siteFromSearch
    : selectedSiteId
      ? siteCatalog.find(item => item.id === selectedSiteId)
      : siteFromSearch;

  if (!site) {
    if (status) status.textContent = "Selecciona un sitio del catalogo para consultar datos.";
    if (detail) detail.innerHTML = "";
    return;
  }

  selectedSiteId = site.id;
  if (status) status.textContent = `Consultando ${site.name}...`;

  try {
    const res = await fetch(`/api/sites/${encodeURIComponent(site.id)}/live`);
    const data = await res.json();
    if (!res.ok || !data.ok) throw new Error(data.error || "No se pudo consultar");
    renderSiteTelemetry(data.site, data.warning);
  } catch (err) {
    if (status) status.textContent = `Error consultando sitio: ${err.message}`;
    if (detail) detail.innerHTML = "";
  }
}

function renderSiteTelemetry(site, warning = "") {
  const status = document.getElementById("siteLiveStatus");
  const detail = document.getElementById("siteLiveDetail");
  if (!site || !detail) return;

  const statusLabel = site.status === "operativo" ? "Operativo" : "Sin comunicacion";
  const age = site.ageMinutes === null ? "Sin fecha" : `${site.ageMinutes} min`;
  const source = site.source === "mysql" ? "BD en vivo" : site.source === "json" ? "JSON local" : "Piloto";
  const metrics = site.metrics || {};
  const rows = [
    ["Gasto", formatMetric(metrics.flow, "L/s")],
    ["Presion", formatMetric(metrics.pressure, "PSI")],
    ["Nivel", formatMetric(metrics.level)],
    ["Bomba/actuador", metrics.pump || "Sin dato"],
    ["Frecuencia", formatMetric(metrics.frequency)],
    ["Voltaje", formatMetric(metrics.voltage)]
  ];

  if (status) {
    status.innerHTML = `
      <strong>${escapeHtml(site.name)}</strong>
      <span>${escapeHtml(site.type)} | ${statusLabel} | ${source}</span>
      ${warning ? `<small>${escapeHtml(warning)}</small>` : ""}
    `;
  }

  detail.innerHTML = `
    <div class="site-live-head ${site.status === "operativo" ? "online" : "offline"}">
      <span></span>
      <div>
        <strong>${statusLabel}</strong>
        <small>Ultima comunicacion: ${escapeHtml(site.lastSeen || "Sin dato")} (${age})</small>
      </div>
    </div>
    <div class="site-metric-grid">
      ${rows.map(([label, value]) => `
        <div>
          <span>${escapeHtml(label)}</span>
          <strong>${escapeHtml(value)}</strong>
        </div>
      `).join("")}
    </div>
    ${renderSiteSeries(site)}
  `;
}

function renderSiteSeries(site) {
  const flows = site.series?.flows || [];
  const pressures = site.series?.pressures || [];
  if (!flows.length && !pressures.length) return "";
  return `
    <div class="site-series">
      ${flows.map(item => `<small>${escapeHtml(item.key)}: <b>${escapeHtml(formatMetric(item.value))}</b></small>`).join("")}
      ${pressures.map(item => `<small>${escapeHtml(item.key)}: <b>${escapeHtml(formatMetric(item.value))}</b></small>`).join("")}
    </div>
  `;
}

function formatMetric(value, unit = "") {
  if (value === null || value === undefined || value === "") return "Sin dato";
  const number = Number(value);
  if (!Number.isNaN(number)) {
    const formatted = Number.isInteger(number) ? String(number) : number.toFixed(2);
    return unit ? `${formatted} ${unit}` : formatted;
  }
  return unit ? `${value} ${unit}` : String(value);
}

function enableDestinationPickMode() {
  setDestinationPickMode(true);
}

function setDestinationPickMode(active) {
  destinationPickMode = active;
  const button = document.getElementById("mapPickButton");
  const coords = document.getElementById("destinationCoords");
  const mapElement = document.getElementById("map");

  button?.classList.toggle("active", active);
  mapElement?.classList.toggle("picking-destination", active);

  if (active && coords) {
    coords.textContent = "Modo seleccion activo: haz clic en el mapa para fijar el destino.";
  } else if (!selectedDestination && coords) {
    coords.textContent = "Usa un pozo del catalogo o activa Marcar punto en mapa.";
  }
}

function clearOperationalDestination() {
  selectedDestination = null;
  setDestinationPickMode(false);

  if (destinationMarker) {
    map.removeLayer(destinationMarker);
    destinationMarker = null;
  }

  const coords = document.getElementById("destinationCoords");
  const nameInput = document.getElementById("destinationName");
  const noteInput = document.getElementById("destinationNote");
  const status = document.getElementById("destinationStatus");

  if (coords) coords.textContent = "Usa un pozo del catalogo o activa Marcar punto en mapa.";
  if (nameInput) nameInput.value = "";
  if (noteInput) noteInput.value = "";
  if (status) status.textContent = "Punto reiniciado. El mapa esta en modo normal.";
}

function selectOperationalDestination(lat, lng) {
  selectedDestination = { lat, lng };
  const coords = document.getElementById("destinationCoords");
  const nameInput = document.getElementById("destinationName");

  if (coords) coords.textContent = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  if (nameInput && !nameInput.value.trim()) {
    nameInput.value = "Destino operativo";
  }

  if (destinationMarker) {
    destinationMarker.setLatLng([lat, lng]);
  } else {
    destinationMarker = L.marker([lat, lng], {
      icon: L.divIcon({
        className: "",
        iconSize: [44, 44],
        iconAnchor: [22, 44],
        html: `<div class="destination-pin"><span></span></div>`
      }),
      zIndexOffset: 9000
    }).addTo(map);
  }

  destinationMarker.bindPopup(`
    <div class="popup-custom">
      <strong>Destino operativo</strong><br>
      ${lat.toFixed(5)}, ${lng.toFixed(5)}
    </div>
  `).openPopup();
}

async function sendOperationalDestination() {
  if (sendingOperationalDestination) return;
  const status = document.getElementById("destinationStatus");
  const button = document.getElementById("sendDestinationButton");
  const target = document.getElementById("destinationTarget")?.value || "all";
  const name = document.getElementById("destinationName")?.value.trim() || "Destino operativo";
  const note = document.getElementById("destinationNote")?.value.trim() || "";

  if (!selectedDestination) {
    if (status) status.textContent = "Selecciona un punto en el mapa.";
    return;
  }

  sendingOperationalDestination = true;
  if (button) button.disabled = true;
  if (status) status.textContent = "Enviando destino...";

  try {
    const res = await fetch("/api/destinations/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        target,
        name,
        note,
        siteId: selectedSiteId || "",
        lat: selectedDestination.lat,
        lng: selectedDestination.lng
      })
    });
    const data = await res.json();

    if (!res.ok || !data.ok) {
      throw new Error(data.error || "No se pudo enviar destino");
    }

    if (status) {
      status.textContent = `Destino enviado a ${target === "all" ? "todas" : target}`;
    }
  } catch (err) {
    if (status) status.textContent = `Error: ${err.message}`;
  } finally {
    sendingOperationalDestination = false;
    if (button) button.disabled = false;
  }
}

function showDestinationStatus(destination) {
  const status = document.getElementById("destinationStatus");
  if (!status || !destination) return;
  const target = destination.target === "all" ? "todas" : destination.target;
  status.textContent = `Ultimo destino: ${target} | ${destination.name}`;

  if (destination.note && !sentMessages.some(item => item.messageId === destination.destinationId)) {
    sentMessages.unshift({
      messageId: destination.destinationId,
      target: destination.target,
      targetTabletId: destination.targetTabletId,
      targetName: destination.targetName,
      type: "destino",
      text: destination.note,
      timestamp: destination.timestamp || Date.now()
    });
    sentMessages = sentMessages.slice(0, 50);
    updateDashboardStats();
    renderMessageTray();
  }
}

async function sendOperationalMessage() {
  if (sendingOperationalMessage) return;
  const target = document.getElementById("messageTarget")?.value || "all";
  const type = document.getElementById("messageType")?.value || "general";
  const textInput = document.getElementById("messageText");
  const status = document.getElementById("messageStatus");
  const button = document.getElementById("sendMessageButton");
  const text = textInput?.value.trim() || "";

  if (!text) {
    if (status) status.textContent = "Escribe un mensaje antes de enviar.";
    return;
  }

  sendingOperationalMessage = true;
  if (button) button.disabled = true;
  if (status) status.textContent = "Enviando...";

  try {
    const res = await fetch("/api/messages/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ target, type, text })
    });
    const data = await res.json();

    if (!res.ok || !data.ok) {
      throw new Error(data.error || "No se pudo enviar");
    }

    if (textInput) textInput.value = "";
    if (status) status.textContent = `Enviado a ${target === "all" ? "todas" : target}`;
    if (!sentMessages.some(item => item.messageId === data.message.messageId)) {
      sentMessages.unshift(data.message);
      sentMessages = sentMessages.slice(0, 50);
    }
    messageTab = "sent";
    updateDashboardStats();
    renderMessageTray();
  } catch (err) {
    if (status) status.textContent = `Error: ${err.message}`;
  } finally {
    sendingOperationalMessage = false;
    if (button) button.disabled = false;
  }
}

function showOperationalMessageStatus(message) {
  const status = document.getElementById("messageStatus");
  if (!status || !message) return;
  const target = message.target === "all" ? "todas" : message.target;
  status.textContent = `Ultimo mensaje: ${target} | ${message.text}`;

  if (!sentMessages.some(item => item.messageId === message.messageId)) {
    sentMessages.unshift(message);
    sentMessages = sentMessages.slice(0, 50);
    updateDashboardStats();
    renderMessageTray();
  }
}

function showOperationalReply(reply) {
  if (!reply) return;
  messageReplies.unshift(reply);
  messageReplies = messageReplies.slice(0, 50);
  messageTab = "replies";
  playMessageTone();
  updateDashboardStats();
  renderMessageTray();
}

function showMessageReadReceipt(receipt) {
  if (!receipt?.messageId) return;
  const readAt = receipt.readAt || receipt.timestamp || Date.now();
  let changed = false;

  sentMessages = sentMessages.map(item => {
    if (item.messageId !== receipt.messageId) return item;
    changed = true;
    return {
      ...item,
      readBy: receipt.tabletId,
      readAt
    };
  });

  if (changed) {
    updateDashboardStats();
    renderMessageTray();
  }
}

function setMessageTab(tab) {
  messageTab = tab;
  renderMessageTray();
}

async function persistDeletedMessages(type, ids) {
  if (!ids.length) return true;
  rememberLocalDeletedMessages(type, ids);

  try {
    const response = await fetch("/api/messages/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ type, ids })
    });
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || "No se pudo eliminar");
  } catch (error) {
    console.log("Eliminacion guardada localmente; servidor pendiente:", error.message);
  }
  return true;
}

async function clearMessageTray() {
  const filter = document.getElementById("messageFilter")?.value || "all";
  const visibleSent = sentMessages.filter(item => filter === "all" || item.target === filter);
  const visibleReplies = messageReplies.filter(item => filter === "all" || item.tabletId === filter);
  const messageIds = visibleSent
    .filter(item => item.type !== "destino")
    .map(item => messageRecordId(item, "sent"));
  const destinationIds = visibleSent
    .filter(item => item.type === "destino")
    .map(item => messageRecordId(item, "sent"));
  const replyIds = visibleReplies.map(item => messageRecordId(item, "replies"));

  const okMessages = await persistDeletedMessages("messages", messageIds);
  const okDestinations = await persistDeletedMessages("destinations", destinationIds);
  const okReplies = await persistDeletedMessages("replies", replyIds);
  if (!okMessages || !okDestinations || !okReplies) return;

  const removeSentIds = new Set([...messageIds, ...destinationIds]);
  const removeReplyIds = new Set(replyIds);
  sentMessages = sentMessages.filter(item => !removeSentIds.has(messageRecordId(item, "sent")));
  messageReplies = messageReplies.filter(item => !removeReplyIds.has(messageRecordId(item, "replies")));

  updateDashboardStats();
  renderMessageTray();
}

async function deleteMessageFromTray(id, tab, event) {
  event?.stopPropagation();
  if (!id) return;

  if (tab === "sent") {
    const item = sentMessages.find(message => messageRecordId(message, "sent") === id);
    const type = item?.type === "destino" ? "destinations" : "messages";
    if (!await persistDeletedMessages(type, [id])) return;
    sentMessages = sentMessages.filter(message => messageRecordId(message, "sent") !== id);
  } else {
    if (!await persistDeletedMessages("replies", [id])) return;
    messageReplies = messageReplies.filter(message => messageRecordId(message, "replies") !== id);
  }

  updateDashboardStats();
  renderMessageTray();
}

function renderMessageTray() {
  const list = document.getElementById("messageList");
  const filter = document.getElementById("messageFilter")?.value || "all";
  const repliesTab = document.getElementById("tabReplies");
  const sentTab = document.getElementById("tabSent");
  if (!list) return;

  repliesTab?.classList.toggle("active", messageTab === "replies");
  sentTab?.classList.toggle("active", messageTab === "sent");

  const source = messageTab === "sent" ? sentMessages : messageReplies;
  const filtered = source.filter(item => {
    if (filter === "all") return true;
    return item.tabletId === filter || item.target === filter;
  });

  if (!filtered.length) {
    list.innerHTML = `<div class="message-empty">Sin ${messageTab === "sent" ? "mensajes enviados" : "respuestas"} en esta vista.</div>`;
    return;
  }

  list.innerHTML = filtered.slice(0, 12).map(item => {
    const isSent = messageTab === "sent";
    const recordId = messageRecordId(item, messageTab);
    const title = isSent
      ? `A ${item.target === "all" ? "todas" : item.target}`
      : (item.tabletId || "Tableta");
    const time = new Date(item.timestamp || Date.now()).toLocaleTimeString();
    const text = messageDisplayHtml(item);
    const readState = isSent
      ? item.readAt
        ? `<small class="read-state read">Leido por ${escapeHtml(item.readBy || item.target || "unidad")} Â· ${new Date(item.readAt).toLocaleString()}</small>`
        : `<small class="read-state pending">No leido</small>`
      : "";

    return `
      <div class="message-item ${isSent ? "sent" : "reply"} ${item.readAt ? "read" : ""}" data-target="${escapeAttribute(isSent ? item.target : item.tabletId)}" data-text="${escapeAttribute(item.text || "")}" onclick="selectMessageForReplyFromElement(this)">
        <strong>${escapeHtml(title)}</strong>
        <span>${time}</span>
        <p>${text}</p>
        ${readState}
        <button class="message-delete" type="button" onclick="deleteMessageFromTray('${escapeAttribute(recordId)}', '${messageTab}', event)">Eliminar</button>
      </div>
    `;
  }).join("");
}

function messageDisplayHtml(item) {
  if (item.type === "evidence") {
    return `Evidencia ${escapeHtml(item.stage || "")} recibida. <a href="${escapeAttribute(item.fileUrl || "#")}" target="_blank" rel="noopener">Ver foto</a>`;
  }
  if (item.type === "order_status") {
    return `Estado de orden: <strong>${escapeHtml(item.status || "")}</strong>`;
  }
  if (item.type === "order_close_report") {
    const evidence = item.evidence || {};
    const totalEvidence = Number(evidence.antes || 0) + Number(evidence.durante || 0) + Number(evidence.despues || 0);
    return `Reporte de cierre recibido: <strong>${escapeHtml(item.name || item.folio || item.destinationId || "orden")}</strong>. Evidencias: ${totalEvidence}`;
  }
  if (item.type === "read_receipt") {
    return `Mensaje leido: ${escapeHtml(item.messageId || "")}`;
  }
  return escapeHtml(item.text || "");
}

function evidenceStripHtml(destinationId) {
  const stages = ["Antes", "Durante", "Despues"];
  const evidences = orderEvidences[destinationId] || {};
  return `
    <div class="task-evidence-strip">
      ${stages.map(stage => {
        const item = evidences[stage];
        if (!item) {
          return `
            <div class="task-evidence empty">
              <span>${stage}</span>
              <strong>Sin foto</strong>
            </div>
          `;
        }

        return `
          <button class="task-evidence ready" type="button" onclick="openEvidence('${escapeAttribute(item.fileUrl || "")}')">
            <span>${stage}</span>
            <img src="${escapeAttribute(item.fileUrl || "")}" alt="Evidencia ${escapeAttribute(stage)}">
            <strong>${escapeHtml(item.tabletId || "Tableta")}</strong>
          </button>
        `;
      }).join("")}
    </div>
  `;
}

function openEvidence(url) {
  if (!url) return;
  window.open(url, "_blank", "noopener");
}

function selectMessageForReplyFromElement(element) {
  selectMessageForReply(element.dataset.target, element.dataset.text);
}

function selectMessageForReply(target, text) {
  if (!target || target === "all") return;
  document.getElementById("opsPanel")?.classList.add("messages-expanded");

  const targetSelect = document.getElementById("messageTarget");
  const destinationTarget = document.getElementById("destinationTarget");
  const messageInput = document.getElementById("messageText");
  const context = document.getElementById("replyContext");

  if (targetSelect) {
    targetSelect.value = target;
  }
  if (destinationTarget) {
    destinationTarget.value = target;
  }
  if (context) {
    context.innerHTML = `
      <strong>Respondiendo a ${escapeHtml(target)}</strong><br>
      <span>${escapeHtml(text || "")}</span>
    `;
  }
  if (messageInput) {
    messageInput.placeholder = `Responder a ${target}`;
    messageInput.value = "";
    messageInput.focus();
  }
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#096;");
}

function alertKey(alerta) {
  return alerta?.id || `${alerta?.tabletId || "Unidad"}:${alerta?.type || "emergency"}`;
}

function showEmergencyAlert(alerta, options = {}) {
  const id = alertKey(alerta);
  const label = alerta.tabletId || "Unidad";
  const lat = parseFloat(alerta.lat);
  const lng = parseFloat(alerta.lng);
  const isEmergency = alerta.type === "emergency" || !alerta.type;
  activeEmergencyAlerts[id] = alerta;

  if (!isNaN(lat) && !isNaN(lng)) {
    if (emergencyMarkers[id]) {
      map.removeLayer(emergencyMarkers[id]);
    }

    const marker = L.marker([lat, lng], {
      icon: L.divIcon({
        className: "",
        iconSize: [84, 84],
        iconAnchor: [42, 42],
        html: `
          <div class="emergency-marker ${isEmergency ? "" : "operational-alert"}">
            <div class="emergency-label">${label}</div>
            <div class="emergency-ring"></div>
            <div class="emergency-ring"></div>
            <div class="emergency-ring"></div>
            <div class="emergency-core"></div>
          </div>
        `
      }),
      zIndexOffset: 10000
    }).addTo(map);

    emergencyMarkers[id] = marker;

    marker.bindPopup(emergencyPopupHtml(id, alerta)).openPopup();

    map.setView([lat, lng], 17);

    if (markers[label]) {
      markers[label].setLatLng([lat, lng]);
      markers[label].openPopup();
    }

    const item = document.getElementById("item_" + label);
    if (item) {
      item.classList.add("unit-emergency");
      item.classList.toggle("unit-operational-alert", !isEmergency);
    }
  }

  if (!options.silent) {
    emergencyPanelHidden = false;
  }

  renderEmergencyPanel();
  resolveEmergencyAddress(id);

  if (!options.silent && isEmergency) {
    startEmergencySound();
  }
}

function emergencyPopupHtml(id, alerta) {
  const lat = parseFloat(alerta.lat);
  const lng = parseFloat(alerta.lng);
  const address = alerta.address || "Buscando direccion...";
  const title = alertTitle(alerta);
  const label = alerta.tabletId || id;

  return `
    <div class="popup-custom emergency-popup">
      <strong>${title}</strong><br>
      <b>${label}</b><br>
      <span>${escapeHtml(alertMessage(alerta))}</span><br>
      <span>${address}</span><br>
      <small>${lat.toFixed(6)}, ${lng.toFixed(6)}</small><br>
      <small>${new Date(alerta.timestamp || Date.now()).toLocaleString()}</small><br>
      <button class="close-alert-btn" onclick="closeEmergency('${id}')">
        ${alerta.type === "emergency" || !alerta.type ? "Cerrar emergencia" : "Cerrar alerta"}
      </button>
    </div>
  `;
}

function alertTitle(alerta) {
  if (alerta?.type === "airplane_mode_enabled") return "MODO AVION ACTIVADO";
  if (alerta?.type === "gps_disabled") return "UBICACION / GPS DESACTIVADO";
  if (alerta?.type === "location_permission_disabled") return "PERMISOS DE UBICACION DESACTIVADOS";
  if (alerta?.type === "background_location_permission_pending") return "PERMISO EN SEGUNDO PLANO PENDIENTE";
  if (alerta?.type === "device_shutdown") return "TABLETA EN PROCESO DE APAGADO";
  if (alerta?.type === "device_power_on") return "TABLETA ENCENDIDA";
  return "ALERTA DE EMERGENCIA";
}

function alertMessage(alerta) {
  if (alerta?.message) return alerta.message;
  if (alerta?.type === "airplane_mode_enabled") return `Se activo el modo avion en ${alerta.tabletId || "la tableta"}.`;
  if (alerta?.type === "gps_disabled") return `Se desactivo la ubicacion/GPS en ${alerta.tabletId || "la tableta"}.`;
  if (alerta?.type === "location_permission_disabled") return `Se quitaron permisos de ubicacion en ${alerta.tabletId || "la tableta"}.`;
  if (alerta?.type === "background_location_permission_pending") return `Falta permiso de ubicacion en segundo plano en ${alerta.tabletId || "la tableta"}.`;
  if (alerta?.type === "device_shutdown") return `La tableta ${alerta.tabletId || ""} se esta apagando.`;
  if (alerta?.type === "device_power_on") return `La tableta ${alerta.tabletId || ""} se encendio.`;
  return "Emergencia reportada desde tableta.";
}

async function resolveEmergencyAddress(id) {
  const alerta = activeEmergencyAlerts[id];
  if (!alerta) return;

  const lat = parseFloat(alerta.lat);
  const lng = parseFloat(alerta.lng);
  if (isNaN(lat) || isNaN(lng)) return;

  const key = `${lat.toFixed(5)},${lng.toFixed(5)}`;
  if (emergencyAddressCache[key]) {
    alerta.address = emergencyAddressCache[key];
    refreshEmergencyDisplay(id);
    return;
  }

  try {
    const res = await fetch(`/api/geocode?lat=${lat}&lng=${lng}`);
    const data = await res.json();
    const address = data.direccion || "Direccion no disponible";
    emergencyAddressCache[key] = address;
    if (activeEmergencyAlerts[id]) {
      activeEmergencyAlerts[id].address = address;
      refreshEmergencyDisplay(id);
    }
  } catch (_) {
    if (activeEmergencyAlerts[id]) {
      activeEmergencyAlerts[id].address = "Direccion no disponible";
      refreshEmergencyDisplay(id);
    }
  }
}

function refreshEmergencyDisplay(id) {
  const alerta = activeEmergencyAlerts[id];
  const marker = emergencyMarkers[id];
  if (alerta && marker) {
    marker.setPopupContent(emergencyPopupHtml(id, alerta));
  }
  renderEmergencyPanel();
}

async function closeEmergency(id) {
  const alerta = activeEmergencyAlerts[id];
  const label = alerta?.type === "emergency" || !alerta?.type ? "emergencia" : "alerta";
  const ok = window.confirm(`Â¿Cerrar ${label} de ${id}?`);
  if (!ok) return;

  try {
    const res = await fetch(`/api/alerts/${encodeURIComponent(id)}/close`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        closedBy: "central",
        reason: "Atendida desde mapa"
      })
    });

    if (!res.ok) {
      window.alert("No se pudo cerrar la emergencia");
    }
  } catch (err) {
    window.alert("Error cerrando emergencia");
  }
}

function closeEmergencyAlert(alerta) {
  const id = alertKey(alerta);
  const label = alerta.tabletId || "Unidad";
  delete activeEmergencyAlerts[id];

  if (emergencyMarkers[id]) {
    map.removeLayer(emergencyMarkers[id]);
    delete emergencyMarkers[id];
  }

  const item = document.getElementById("item_" + label);
  if (item) {
    const stillHasAlert = Object.values(activeEmergencyAlerts).some(itemAlert => itemAlert.tabletId === label);
    if (!stillHasAlert) {
      item.classList.remove("unit-emergency");
      item.classList.remove("unit-operational-alert");
    }
  }

  renderEmergencyPanel();
  updateDashboardStats();
  if (!Object.keys(activeEmergencyAlerts).length) {
    stopEmergencySound();
  }
}

function renderEmergencyPanel() {
  let panel = document.getElementById("emergencyPanel");
  const alerts = Object.values(activeEmergencyAlerts);
  updateDashboardStats();

  if (!panel) {
    panel = document.createElement("div");
    panel.id = "emergencyPanel";
    document.body.appendChild(panel);
  }

  if (!alerts.length || emergencyPanelHidden) {
    panel.classList.remove("visible");
    panel.classList.remove("operational-alert");
    panel.innerHTML = "";
    renderEmergencyDock(alerts.length);
    return;
  }

  renderEmergencyDock(0);
  const hasEmergency = alerts.some(alerta => alerta.type === "emergency" || !alerta.type);
  panel.classList.add("visible");
  panel.classList.toggle("operational-alert", !hasEmergency);
  panel.innerHTML = `
    <div class="emergency-panel-header">
      <strong>${hasEmergency ? "ALERTAS ACTIVAS" : "ALERTAS OPERATIVAS"}</strong>
      <span>${alerts.length}</span>
      <button class="silence-alert-btn" onclick="hideEmergencyPanel()">
        Ocultar / silenciar
      </button>
    </div>
    ${alerts.map(alerta => {
      const id = alertKey(alerta);
      const label = alerta.tabletId || "Unidad";
      const lat = parseFloat(alerta.lat);
      const lng = parseFloat(alerta.lng);
      const time = new Date(alerta.timestamp || Date.now()).toLocaleTimeString();
      const address = alerta.address || "Buscando direccion...";
      const message = alertMessage(alerta);

      return `
        <div class="emergency-panel-item">
          <button onclick="focusEmergency('${id}')">
            ${alertTitle(alerta)} | ${label}<br>
            <small>${escapeHtml(message)}</small><br>
            <small>${address}</small><br>
            <small>${time} | ${lat.toFixed(5)}, ${lng.toFixed(5)}</small>
          </button>
        </div>
      `;
    }).join("")}
  `;
}

function hideEmergencyPanel() {
  emergencyPanelHidden = true;
  stopEmergencySound();
  renderEmergencyPanel();
}

function showEmergencyPanel() {
  emergencyPanelHidden = false;
  renderEmergencyPanel();
}

function renderEmergencyDock(count) {
  let dock = document.getElementById("emergencyDock");

  if (!dock) {
    dock = document.createElement("button");
    dock.id = "emergencyDock";
    dock.onclick = showEmergencyPanel;
    document.body.appendChild(dock);
  }

  if (!count) {
    dock.classList.remove("visible");
    dock.classList.remove("operational-alert");
    dock.textContent = "";
    return;
  }

  dock.classList.add("visible");
  const hasEmergency = Object.values(activeEmergencyAlerts).some(alerta => alerta.type === "emergency" || !alerta.type);
  dock.classList.toggle("operational-alert", !hasEmergency);
  dock.textContent = `Mostrar ${hasEmergency ? "emergencias" : "alertas operativas"} activas (${count})`;
}

function focusEmergency(id) {
  const alerta = activeEmergencyAlerts[id];
  if (!alerta) return;

  const lat = parseFloat(alerta.lat);
  const lng = parseFloat(alerta.lng);

  if (!isNaN(lat) && !isNaN(lng)) {
    map.setView([lat, lng], 17);
    if (emergencyMarkers[id]) {
      emergencyMarkers[id].openPopup();
    }
  }
}

function playEmergencyTone() {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;

    const ctx = new AudioContext();
    [0, 0.35, 0.7].forEach(offset => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "square";
      osc.frequency.value = 880;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + offset);
      gain.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + offset + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + offset + 0.25);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + offset);
      osc.stop(ctx.currentTime + offset + 0.28);
    });
  } catch (_) {}
}

function playMessageTone() {
  try {
    const AudioContext = window.AudioContext || window.webkitAudioContext;
    if (!AudioContext) return;

    const ctx = new AudioContext();
    [0, 0.18].forEach((offset, index) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = index === 0 ? 660 : 880;
      gain.gain.setValueAtTime(0.0001, ctx.currentTime + offset);
      gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + offset + 0.03);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + offset + 0.16);
      osc.connect(gain).connect(ctx.destination);
      osc.start(ctx.currentTime + offset);
      osc.stop(ctx.currentTime + offset + 0.18);
    });
  } catch (_) {}
}

function startEmergencySound() {
  playEmergencyTone();

  if (emergencySoundTimer) return;

  emergencySoundTimer = setInterval(() => {
    if (!Object.keys(activeEmergencyAlerts).length || emergencyPanelHidden) {
      stopEmergencySound();
      return;
    }
    playEmergencyTone();
  }, 4500);
}

function stopEmergencySound() {
  if (emergencySoundTimer) {
    clearInterval(emergencySoundTimer);
    emergencySoundTimer = null;
  }
}

function syncEmergencyMarker(id, lat, lng, refreshPanel = false) {
  if (isNaN(lat) || isNaN(lng)) return;
  const matchingIds = Object.entries(activeEmergencyAlerts)
    .filter(([, alerta]) => alertKey(alerta) === id || alerta.tabletId === id || alerta.sourceTabletId === id)
    .map(([alertId]) => alertId);
  if (!matchingIds.length) return;

  matchingIds.forEach(alertId => {
    const alerta = activeEmergencyAlerts[alertId];
    alerta.lat = lat;
    alerta.lng = lng;
    activeEmergencyAlerts[alertId] = alerta;

    const marker = emergencyMarkers[alertId];
    if (marker) {
      marker.setLatLng([lat, lng]);
      marker.setPopupContent(emergencyPopupHtml(alertId, alerta));
    }
  });

  if (refreshPanel) {
    renderEmergencyPanel();
    const lookupKey = matchingIds[0];
    const lastLookup = emergencyAddressLookupAt[lookupKey] || 0;
    if (Date.now() - lastLookup > 60000) {
      emergencyAddressLookupAt[lookupKey] = Date.now();
      resolveEmergencyAddress(lookupKey);
    }
  }
}

function updateDashboardStats() {
  const units = Object.values(unitStates);
  const online = units.filter(unit => unit.online).length;
  const offline = units.length - online;
  const activeAlerts = Object.values(activeEmergencyAlerts);
  const emergencies = activeAlerts.filter(alert => alert.type === "emergency" || !alert.type).length;
  const operationalAlerts = activeAlerts.length - emergencies;
  const alerts = activeAlerts.length;
  const messages = messageReplies.length + sentMessages.length;
  const tasks = activeDestinationTasks.length;

  setText("topOnline", online);
  setText("fleetOnline", online);
  setText("mapOnline", online);
  setText("topAlerts", alerts);
  setText("fleetAlerts", alerts);
  setText("mapAlerts", alerts);
  setText("topMessages", messages);
  setText("mapMessages", messages);
  setText("topTasks", tasks);
  setText("mapTasks", tasks);
  setText("fleetOffline", offline);
  updateAlertCounterLabels(emergencies, operationalAlerts);
}

function updateAlertCounterLabels(emergencies, operationalAlerts) {
  const label = operationalAlerts > 0
    ? `${emergencies} emergencia(s), ${operationalAlerts} operativa(s)`
    : `${emergencies} emergencia(s)`;
  document.querySelectorAll(".top-chip.alert small, .metric.alert small").forEach(element => {
    element.textContent = operationalAlerts > 0 ? "Emerg. / Oper." : "Emergencias";
    element.title = label;
  });
  const fleetAlert = document.querySelector(".fleet-stats .alert span");
  if (fleetAlert) {
    fleetAlert.textContent = operationalAlerts > 0 ? "Alertas mixtas" : "Alertas";
    fleetAlert.title = label;
  }
}

function setText(id, value) {
  const element = document.getElementById(id);
  if (element) element.textContent = value;
}

function renderUnitDetail(unit) {
  const detail = document.getElementById("unitDetail");
  if (!detail) return;

  if (!unit) {
    detail.innerHTML = `
      <span class="status-dot"></span>
      <h3>Selecciona una unidad</h3>
      <p>Haz clic en una unidad del mapa o de la lista.</p>
    `;
    return;
  }

  const emergency = activeEmergencyAlerts[unit.id] ? "Con alerta activa" : "Sin alerta";
  const addressKey = `${unit.lat.toFixed(5)},${unit.lng.toFixed(5)}`;
  const address = activeEmergencyAlerts[unit.id]?.address || unitAddressCache[addressKey] || "Consultando direccion...";

  detail.innerHTML = `
    <span class="status-dot ${unit.online ? "online" : "offline"}"></span>
    <h3>${escapeHtml(unit.id)}</h3>
    <p>${unit.online ? "Online" : "Offline"} | ${emergency}</p>
    <div class="unit-detail-grid">
      <span>Ultima actividad</span><strong>${new Date(unit.timestamp || Date.now()).toLocaleTimeString()}</strong>
      <span>Direccion aproximada</span><strong id="unitDetailAddress">${escapeHtml(address)}</strong>
      <span>Coordenadas</span><strong>${unit.lat.toFixed(5)}, ${unit.lng.toFixed(5)}</strong>
      <span>Aplicacion</span><strong>${unit.appId === "jmas-operativa-v2" ? `Seguridad Operativa ${escapeHtml(unit.appVersion || "")}` : "Aplicacion anterior"}</strong>
      <span>Departamento</span><strong>${departmentSelectHtml(unit)}</strong>
    </div>
    <div class="unit-actions">
      <button onclick="prepareMessageForSelectedUnit()">Mensaje</button>
      <button onclick="prepareDestinationForSelectedUnit()">Destino</button>
      <button class="danger" onclick="deleteSelectedUnit()">Eliminar prueba</button>
    </div>
  `;

  if (!unitAddressCache[addressKey] && !activeEmergencyAlerts[unit.id]?.address) {
    resolveUnitAddress(unit.id, unit.lat, unit.lng, addressKey);
  }
}

async function deleteSelectedUnit() {
  const unit = selectedUnitData;
  if (!unit) return;

  const warning = unit.online
    ? "Esta unidad esta online y volvera a aparecer si sigue transmitiendo."
    : "Se eliminara del mapa y del registro actual.";
  if (!confirm(`Eliminar ${unit.id}?\n\n${warning}`)) return;

  try {
    const identifier = unit.tabletId || unit.id;
    const response = await fetch(`/api/devices/${encodeURIComponent(identifier)}`, {
      method: "DELETE"
    });
    const data = await response.json();
    if (!response.ok || !data.ok) {
      throw new Error(data.error || "No se pudo eliminar la unidad");
    }
    removeUnit(unit.id);
  } catch (error) {
    alert(error.message || "No se pudo eliminar la unidad");
  }
}

async function resolveUnitAddress(unitId, lat, lng, addressKey, attempt = 0) {
  try {
    const res = await fetch(`/api/geocode?lat=${lat}&lng=${lng}`);
    const data = await res.json();
    const address = data.direccion || "Direccion no disponible";

    if (address === "Consultando..." && attempt < 4) {
      setTimeout(
        () => resolveUnitAddress(unitId, lat, lng, addressKey, attempt + 1),
        1_250 + attempt * 500
      );
      return;
    }

    unitAddressCache[addressKey] = address;

    if (selectedUnitData?.id === unitId) {
      const addressElement = document.getElementById("unitDetailAddress");
      if (addressElement) addressElement.textContent = unitAddressCache[addressKey];
    }
  } catch (_) {
    unitAddressCache[addressKey] = "Direccion no disponible";
  }
}



// ================= UPDATE =================
// ================= UPDATE =================
function updateUnidad(u) {

  const id = u.id;
  if (!id) return;
  let lat = parseFloat(u.lat);
  let lng = parseFloat(u.lng);
  const pointTime = Number.isFinite(Number(u.timestamp)) ? Number(u.timestamp) : Date.now();
  const stablePoint = normalizeStablePoint(id, lat, lng, pointTime);
  lat = stablePoint.lat;
  lng = stablePoint.lng;
  if (!shouldAcceptPosition(id, lat, lng, pointTime)) {
    return;
  }

  ensureMessageTarget(id);
  syncEmergencyMarker(id, lat, lng, true);

  const now = Date.now();
  const online = (now - pointTime) <= 180000;
  const estadoTexto = online ? "Online" : "Offline";
  unitStates[id] = {
    ...u,
    id,
    lat,
    lng,
    timestamp: pointTime,
    department: u.department || "Sin asignar",
    tabletId: u.tabletId || id,
    online
  };
  registerDepartment(unitStates[id].department);
  const estado = online ? "Online" : "Offline";

  
  // ===== ROTACIÃ“N =====
  let angulo = 0;

  if (posicionesPrevias[id]) {
    const headingDistance = L.latLng(posicionesPrevias[id].lat, posicionesPrevias[id].lng).distanceTo([lat, lng]);
    if (headingDistance < 10) {
      angulo = markers[id]?._lastAngle || 0;
    } else {
    angulo = calcularAngulo(
      posicionesPrevias[id].lat,
      posicionesPrevias[id].lng,
      lat,
      lng
    );
    }
  }

  posicionesPrevias[id] = { lat, lng };

  // ===== MAPA =====
  if (!markers[id]) {

    markers[id] = L.marker([lat, lng], {
      icon: getIcon(id, online, angulo) // ðŸ”¥ PASAR ANGULO
    });
    unitMarkerLayer.addLayer(markers[id]);

    // ðŸ”¥ guardar Ã¡ngulo inicial
    markers[id]._lastAngle = angulo;

    // ðŸ”¥ crear popup una sola vez
    markers[id].bindPopup("");

    // ðŸ”¥ permitir click directo
    markers[id].on("click", () => {
      unidadSeleccionada = id;
      selectedUnitData = unitStates[id];
      setOperationalTargets(id);
      setFocusedUnit(id);
      renderUnitDetail(selectedUnitData);
      markers[id].openPopup();
    });

  } else {

    // ===== MOVIMIENTO SUAVE =====
    if (!destinos[id]) destinos[id] = [];

   const lastQueued = destinos[id][destinos[id].length - 1];
   const queuedDistance = lastQueued
     ? L.latLng(lastQueued.lat, lastQueued.lng).distanceTo([lat, lng])
     : Infinity;

   if (queuedDistance >= 6 || destinos[id].length === 0) {
     destinos[id].push({ lat, lng, timestamp: pointTime });
   }

// ðŸ”¥ buffer mÃ­nimo antes de iniciar
if (!animacionesActivas[id] && destinos[id].length >= 5) {
  moverSuave(id);
}

    // ===== ROTACIÃ“N SUAVE =====
    let prevAngle = markers[id]._lastAngle || angulo;

    let diff = angulo - prevAngle;

    if (diff > 180) diff -= 360;
    if (diff < -180) diff += 360;

    let nuevoAngulo = prevAngle + diff * 0.2;

    markers[id]._lastAngle = nuevoAngulo;

    // ðŸ”¥ ACTUALIZAR ICONO CON ROTACIÃ“N
    markers[id].setIcon(getIcon(id, online, nuevoAngulo));
  }

  // ===== ACTUALIZAR POPUP =====
if (markers[id].getPopup()) {
  markers[id].getPopup().setContent(`
    <div class="popup-custom">
      <strong>${id}</strong><br>
      <span class="${online ? 'on' : 'off'}">
        ${estado}
      </span>
    </div>
  `);
}
  // ===== FOLLOW =====
  if (unidadSeleccionada === id) {
    map.setView([lat, lng]);
  }

  // ===== LISTA =====
  let item = document.getElementById("item_" + id);

  if (!item) {
    item = document.createElement("li");
    item.id = "item_" + id;
    item.dataset.unit = id;
    lista.appendChild(item);
  }
  item.dataset.department = unitStates[id].department || "Sin asignar";

  const initials = id
    .split(/[\s_-]+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(part => part[0])
    .join("")
    .toUpperCase()
    .slice(0, 2) || "U";

  item.classList.toggle("offline", !online);
  item.classList.toggle("unit-emergency", Boolean(activeEmergencyAlerts[id]));
  item.innerHTML = `
    <span class="unit-avatar">${initials}</span>
    <span class="unit-name">${id}<small>${escapeHtml(unitStates[id].department || "Sin asignar")}</small></span>
    <span class="unit-state ${online ? "online" : "offline"}">${estadoTexto}</span>
  `;

  item.onclick = () => {

    unidadSeleccionada = id;
    selectedUnitData = unitStates[id];
    setOperationalTargets(id);
    setFocusedUnit(id);

    document.querySelectorAll("li").forEach(li => {
      li.style.background = "";
      li.classList.remove("selected");
    });

    item.classList.add("selected");

    map.setView([lat, lng], 16);
    markers[id].openPopup();
    renderUnitDetail(selectedUnitData);
  };

  if (selectedUnitData?.id === id) {
    selectedUnitData = unitStates[id];
    renderUnitDetail(selectedUnitData);
  }

  updateDashboardStats();
  filterUnits();
}

function removeUnit(id) {
  if (!id) return;

  if (markers[id]) {
    unitMarkerLayer.removeLayer(markers[id]);
    delete markers[id];
  }

  const item = document.getElementById("item_" + id);
  if (item) item.remove();

  delete unitStates[id];
  delete destinos[id];
  delete posicionesPrevias[id];
  delete lastAcceptedPositions[id];
  delete stationaryLocks[id];
  delete animacionesActivas[id];

  if (unidadSeleccionada === id) {
    detenerSeguimiento();
  }

  updateDashboardStats();
}

loadDepartments();
loadRecentMessages();
